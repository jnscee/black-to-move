// All embedded artwork was produced for Black to Move. build.py inserts the WebP data below.
