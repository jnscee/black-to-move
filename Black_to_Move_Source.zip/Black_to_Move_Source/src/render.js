const field = document.getElementById('arena'), ctx = field.getContext('2d');
const pictures = {}, assetsReady = [];
for (const group of Object.keys(MANOR)) {
  pictures[group] = {};
  for (const [key, url] of Object.entries(MANOR[group])) {
    const im = new Image();
    im.src = url;
    pictures[group][key] = im;
    assetsReady.push(im.decode());
  }
}
const images = pictures.figures, sprites = images;
const mapCache = new Map();
const WALL = 2.65, TILE = 80;
const roomArt = [
  {key:'hall', seam:267},
  {key:'gallery', seam:245},
  {key:'ballroom', seam:246}
];
// The panorama has its own wall band above y=0. The collision rectangles remain in metres.
function floorArt(room) {
  if (mapCache.has(room)) return mapCache.get(room);
  const scene = roomArt[room], im = pictures.rooms[scene.key];
  if (!im.naturalWidth || (room === 1 && !pictures.props.shelf.naturalWidth)) return null;
  const map = document.createElement('canvas');
  map.width = TILE*20;
  map.height = Math.round(TILE*(12+WALL));
  const pen = map.getContext('2d');
  pen.scale(TILE,TILE);
  pen.translate(0,WALL);
  function backdrop(top,height,sy,sh) {
    pen.drawImage(im,0,sy,im.naturalWidth,sh,0,top,20,height);
  }
  if (room === 1) {
    backdrop(-WALL,WALL+1,0,scene.seam);
    // The northern bypass and main aisle have separate runs of marquetry within the woodwork.
    backdrop(1,2,scene.seam,im.height-scene.seam);
    backdrop(3,4.5,scene.seam,im.height-scene.seam);
    const shelf = pictures.props.shelf;
    for (const [x,y,w,h] of ROOMS[room].blocks) {
      if (y===0) continue;
      pen.fillStyle='#372b2c';
      pen.fillRect(x,y,w,h);
      const count=Math.round(w/2.55),rows=h>2?2:1;
      for(let r=0;r<rows;r++){
        for(let i=0;i<count;i++){
          if(shelf.naturalWidth) pen.drawImage(shelf,x+i*w/count,y+r*h/rows,w/count+.018,h/rows);
        }
      }
      const bevel=pen.createLinearGradient(0,y,0,y+h);
      bevel.addColorStop(0,'#ffdeb01c');bevel.addColorStop(.12,'#0000');
      bevel.addColorStop(.85,'#17132211');bevel.addColorStop(1,'#19102266');
      pen.fillStyle=bevel;pen.fillRect(x,y,w,h);
      pen.fillStyle='#27182742';pen.fillRect(x,y+h,w,.1);
    }
  } else {
    backdrop(-WALL,WALL,0,scene.seam);
    backdrop(0,12,scene.seam,im.height-scene.seam);
  }
  mapCache.set(room,map);
  return map;
}
let view={iso:false}, camera={};
function setupCamera(g){
  const W=field.clientWidth,H=field.clientHeight,dpr=Math.min(window.devicePixelRatio||1,2);
  if(field.width!==Math.round(W*dpr)||field.height!==Math.round(H*dpr)){
    field.width=Math.round(W*dpr);field.height=Math.round(H*dpr);
  }
  let a,b,c,d,e,f;
  if(view.iso){
    const scale=Math.min((W-16)/((32+WALL)*.707),(H-22)/((32+WALL)*.354));
    a=scale*.707;c=-a;b=d=scale*.354;
    e=W/2-(4+WALL*.5)*a;
    f=H/2-(16-WALL*.5)*b+6;
  }else{
    d=H/(12+WALL);
    a=W<600?Math.max(W/8.0,d*.95):Math.max(W/20,d*1.14);
    b=c=0;
    const span=W/(2*a);
    e=W/2-(span>=10?10:clamp(g.player.x,span,20-span))*a;
    f=WALL*d;
  }
  camera={a,b,c,d,e,f,W,H,dpr,scale:Math.hypot(a,c)};
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
function project(p) {
  const {a, b, c, d, e, f} = camera;
  return point(a * p.x + c * p.y + e, b * p.x + d * p.y + f);
}
function ground(p, r, color, fill = false, width = 1.5) {
  const v = project(p), s = camera.scale;
  ellipse(v.x, v.y, s * r, r * (view.iso?s*.5:camera.d), color, fill, width);
}
function loopPath(points, fill, edge, width = 1) {
  ctx.beginPath();
  points.forEach((v, i) => i?ctx.lineTo(v.x, v.y):ctx.moveTo(v.x, v.y));
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (edge) {
    ctx.strokeStyle = edge;
    ctx.lineWidth = width;
    ctx.stroke();
  }
}
function lineWorld(a, b, col, w = 1) {
  const p = project(a), q = project(b);
  stroke(p.x, p.y, q.x, q.y, col, w);
}
function drawDirectionalEffect(f, color) {
  const angle = Math.atan2(f.b.y, f.b.x), span = f.degrees * Math.PI / 180, points = [project(f.a)];
  for (let i = 0;i <= 20;i++) {
    const a = angle - span / 2 + span * i / 20;
    points.push(project(point(f.a.x + Math.cos(a) * f.range, f.a.y + Math.sin(a) * f.range)));
  }
  loopPath(points, color, '#ffe0b5', 1.2);
}
function drawMovingEffect(g, f) {
  const life = (g.tick - f.start) / (f.end - f.start), p = project(f.a), q = project(f.b), s = camera.scale;
  ctx.save();
  ctx.globalAlpha = Math.min(1, (1 - life) * 2);
  if (f.type === 'beam') {
    const bright = f.followUp?'#e3f3ff':'#fff2ba';
    lineWorld(f.a, f.b, f.followUp?'#9fc9e5aa':'#c97574a8', Math.max(2, s * f.width));
    lineWorld(f.a, f.b, bright, 1.8);
    const t = Math.min(1, life * 4);
    ellipse(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, 3.3, 2, bright, true);
    const flash = s * .24 * (1 - life);
    stroke(p.x - flash, p.y, p.x + flash, p.y, bright);
    stroke(p.x, p.y - flash, p.x, p.y + flash, bright);
    if (f.hits >= 2) {
      ctx.font = 'bold ' + Math.max(10, s * .26) + 'px sans-serif';
      ctx.textAlign = 'center';
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#263139';
      ctx.strokeText('관통 ×' + f.hits, p.x, p.y - s * 1.1);
      ctx.fillStyle = bright;
      ctx.fillText('관통 ×' + f.hits, p.x, p.y - s * 1.1);
    }
  }
  if (f.type === 'silver') {
    const travel = Math.min(1, life * 2.8), x = p.x + (q.x - p.x) * travel, y = p.y + (q.y - p.y) * travel - s * (.97-.36*travel);
    const v = unit(q.x - p.x, q.y - p.y);
    stroke(x - v.x * s * .65, y - v.y * s * .65, x, y, '#b8d9e0', 1.6);
    ctx.translate(x, y);
    ctx.rotate(Math.atan2(v.y, v.x));
    ctx.fillStyle = '#f4ead2';
    ctx.fillRect(-7, -1, 11, 2);
    for (let i = -1;i <= 1;i++)ctx.fillRect(3, i * 2, 4, 1);
  }
  if (f.type === 'snake') {
    const points = [];
    for (let i = 0;i <= 16;i++) {
      const t = i / 16;
      points.push(point(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t + Math.sin(i * .7 - life * 8) * 3));
    }
    for (let i = 1;i < points.length;i++)stroke(points[i - 1].x, points[i - 1].y, points[i].x, points[i].y, '#b1d2a2', 2);
  }
  if(f.type==='silverPick'){
    ground(f.a,.12+.52*life,'#b5fff1',false,2.2);
    const x=p.x+clamp(s*.4,13,30),y=p.y-s*.95-18*life;
    ctx.font='bold 14px system-ui,sans-serif';ctx.textAlign='left';ctx.lineWidth=3.5;
    ctx.strokeStyle='#07343b';ctx.strokeText('파편 +1',x,y);
    ctx.fillStyle='#c4fff2';ctx.fillText('파편 +1',x,y);
  }
  if (['shock', 'guard', 'death', 'hurt', 'heal'].includes(f.type))
  ground(f.a, (f.range || .65) * (.25 + .75 * life), ({guard:'#97c9ec', death:'#e6b7a2', hurt:'#ff727c', heal:'#a6e6a3'})[f.type] || '#dfd29d');
  if (f.type === 'slash' || f.type === 'open')
  drawDirectionalEffect(f, f.type === 'slash'?'#ffdd9677':'#c2d7de66');
  if (f.type === 'number') {
    ctx.font = 'bold ' + Math.max(10, s * .31) + 'px Georgia';
    ctx.textAlign = 'center';
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#212a35';
    const y = p.y - s * (1.47 + .56 * life);
    ctx.strokeText(f.value, p.x, y);
    ctx.fillStyle = '#fbdfac';
    ctx.fillText(f.value, p.x, y);
  }
  ctx.restore();
}
function drawThreat(e) {
  if (e.mode !== 'warn' && e.mode !== 'dash')return;
  const length = e.kind === 'boss'?3.25:2.25, half = e.radius;
  const side = point(-e.dy * half, e.dx * half), end = point(e.x + e.dx * length, e.y + e.dy * length);
  lineWorld(e,end,'#4b162cb0',Math.max(4,camera.scale*.14));
  loopPath([point(e.x + side.x, e.y + side.y), point(end.x + side.x, end.y + side.y), point(end.x - side.x, end.y - side.y), point(e.x - side.x, e.y - side.y)].map(project), '#9c224d85', '#ffb2b9', 2);
  ctx.save();
  ctx.setLineDash([5, 4]);
  lineWorld(e, end, '#fff0bf', 1.8);
  ctx.restore();
}
function paint(g) {
  setupCamera(g);
  const {a, b, c, d, e, f, W, H, dpr, scale:s} = camera;
  if (!W || !H)return;
  ctx.fillStyle = '#1a273a';
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.transform(a, b, c, d, e, f);
  const map=floorArt(g.room);
  if(map)ctx.drawImage(map,0,-WALL,20,12+WALL);
  ctx.restore();
  if(g.room<2){
    const gate=point(19,6),p=project(gate),opened=g.door;
    ground(gate,.55,opened?'#297565b8':'#1b2d47b8',true);
    ground(gate,.55,opened?'#b7ffdc':'#e2e5ef',false,2);
    ctx.font='bold '+Math.max(13,s*.45)+'px Georgia';ctx.textAlign='center';
    ctx.fillStyle='#fff7df';ctx.fillText('→',p.x,p.y+Math.max(5,s*.11));
    const label=opened?'출구 개방':'출구';
    ctx.font='bold '+Math.max(11,s*.22)+'px sans-serif';ctx.lineWidth=3;ctx.strokeStyle='#263246';
    ctx.strokeText(label,p.x,p.y-Math.max(15,s*.52));ctx.fillText(label,p.x,p.y-Math.max(15,s*.52));
  }
  for (const w of g.warnings) {
    ground(w, .34, '#efa290', false, 2);
    ground(w, Math.max(.07, .45 * (w.end - g.tick) / 36), '#e88f7766', true);
  }
  for (const fire of g.fires) {
    ground(fire, .8 + .14*g.orderRank, '#b256336e', true);
    const p = project(fire);
    for (let i = 0;i < 7;i++) {
      const angle = i * 2.4, x = p.x + Math.cos(angle) * s * .55, y = p.y + Math.sin(angle) * s * .34;
      loopPath([point(x - 3, y), point(x + 1, y - 6 - (g.tick + i) % 8), point(x + 4, y)], i % 2?'#eaa450':'#d77747');
    }
  }
  drawSilverDrops(g);
  for (const item of g.items) {
    const p = project(item);
    ground(item, .34, '#c1deb287', true);
    ctx.fillStyle = '#e5d9b9';
    ctx.fillRect(p.x - 7, p.y - 12, 14, 11);
    ctx.fillStyle = '#7e4241';
    ctx.fillRect(p.x - 2, p.y - 11, 4, 9);
    ctx.fillRect(p.x - 5, p.y - 8, 10, 3);
  }
  const tables=ROOMS[g.room].blocks.filter(rect=>rect[4]==='table').map(([x,y,w,h])=>[{x:x+w/2,y:y+h,w,h},'table']);
  const all = [...tables,...g.enemies.map(v => [v, 'enemy']), ...g.units.map(v => [v, 'ally']), [g.player, 'lead']].sort((a, b) => project(a[0]).y - project(b[0]).y);
  ctx.imageSmoothingEnabled = false;
  for (const [v, kind] of all) {
    if(kind==='table'){
      const im=pictures.props[g.room===0?'iris-table':'service-table'];
      if(!im.naturalWidth)continue;
      const feet=project(v),back=project(point(v.x,v.y-v.h));
      const shortSide=view.iso?s*.93:camera.d;
      const width=(view.iso?2.5:v.w)*s, height=v.h*shortSide+(g.room===0?.67:.55)*s;
      ctx.save();
      ctx.globalAlpha=distance(v,g.player)<2&&project(g.player).y<feet.y&&Math.abs(project(g.player).x-feet.x)<width*.5?.72:1;
      ellipse(feet.x,feet.y-shortSide*.13,width*.5,shortSide*.30,'#311b2859',true);
      ctx.drawImage(im,(view.iso?(feet.x+back.x)*.5:feet.x)-width*.5,feet.y-height,width,height);
      ctx.restore();continue;
    }
    const p = project(v), lead = kind === 'lead', foe = kind === 'enemy', dir = lead || !foe?g.facing.x:g.player.x - v.x;
    const h = s * (lead?1.78:foe?(v.kind === 'boss'?2.23:v.kind === 'elite'?1.51:1.4):1.44);
    ellipse(p.x, p.y, s * (lead?.31:.26), s * .095, '#101a22aa', true);
    if (foe && slowAt(g, v) > 0)ground(v, v.radius + .06, '#b0d49e');
    const frame = Math.floor(g.walk * 2.5) % 2;
    const im = lead?images['hero' + (1 + frame)]:foe?sprites[v.kind]:images[v.key];
    ctx.save();
    ctx.shadowColor=lead?'#e5f0ffe0':'#21243b88';ctx.shadowBlur=lead?2.4:1.35;
    if(foe&&v.flash>g.tick)ctx.filter='brightness(1.6)';
    if (lead && g.immune > g.tick)ctx.globalAlpha = .63 + .25 * Math.abs(Math.sin(g.tick * .24));
    const bob = foe && v.mode === 'chase'?Math.floor((g.tick + v.id) / 14) % 2:0;
    if (foe && v.mode === 'warn') {
      ctx.translate(p.x, p.y);
      ctx.transform(1, 0, .19 * Math.sign(v.dx || 1), .9, 0, 0);
      sprite(im, 0, 0, Math.round(h), dir < 0?-1:1);
    }
    else if (im?.width)sprite(im, p.x, p.y - bob, Math.round(h), dir < 0?-1:1);
    ctx.restore();
    if (foe && v.hp < v.max) {
      const w = s * .62;
      ctx.fillStyle = '#222831';
      ctx.fillRect(p.x - w / 2, p.y - h - 4, w, 2.5);
      ctx.fillStyle = '#db928c';
      ctx.fillRect(p.x - w / 2, p.y - h - 4, w * v.hp / v.max, 2.5);
    }
    if (foe && v.kind === 'elite') {
      ctx.fillStyle = '#e8cf88';
      ctx.font = '13px serif';
      ctx.fillText('✦', p.x, p.y - h - 6);
    }
  }
  drawSilverShots(g);
  for (const fx of g.effects)drawMovingEffect(g, fx);
  for (const v of g.enemies)drawThreat(v);
  const foot = project(g.player);
  ground(g.player, .22, '#182541', false, 3.6);
  ground(g.player, .22, g.immune > g.tick?'#aee8ff':'#ffdf98', false, 1.5);
  const fx = project(point(g.player.x + g.facing.x * .37, g.player.y + g.facing.y * .37));
  stroke(foot.x, foot.y, fx.x, fx.y, '#fff2b9', 1.7);
  if (g.shield > g.tick)ground(g.player, .44, '#a4defa', false, 2);
  if (g.room < 2 && project(point(19, 6)).x > W - 8) {
    ctx.fillStyle = '#eddfbd';
    ctx.font = 'bold 12px sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('출구 →', W - 10, Math.max(24, project(point(19, 6)).y));
  }
}
