// Silver supply has its own deterministic random stream. All cooldowns use simulation ticks.
const SILVER_TIERS = [
  {need:0, name:'은식기 투척', forks:0, forkTime:0},
  {need:1, name:'쌍투', forks:2, forkTime:50},
  {need:5, name:'부채 투척', forks:5, forkTime:42},
  {need:12, name:'회전 나이프', forks:6, forkTime:38, ring:10, ringTime:64},
  {need:26, name:'이중 나선', forks:7, forkTime:34, ring:13, ringTime:43, spiral:3},
  {need:40, name:'은빛 소나기', forks:9, forkTime:29, ring:18, ringTime:39, spiral:4, rain:12},
  {need:54, name:'은식기 폭풍', forks:11, forkTime:24, ring:24, ringTime:34, spiral:6, rain:22}
];
const SUPPLY_PATHS = [
  [[3.7,6],[2.35,3.35],[2.5,8.5],[6,2.3],[11.5,2.35],[16.5,3],[17,8.8],[12,9.6],[6.4,9.3],[13.9,6.4],[6,5.8]],
  [[3.6,6],[2.4,2.5],[6,2],[10.2,2],[14.9,2],[17.8,2.3],[17.6,6.2],[13.6,6.1],[8.8,6],[6.2,5.8]],
  [[3.8,6],[4.9,3.3],[8.5,2.8],[13,3.2],[16.6,6.9],[11,9],[6,8.8],[10,6]]
];
function initSilver(g) {
  g.orderRank = 0;
  g.silver = {count:0, tier:0, fired:0, hits:0, peak:0, pickups:[], bursts:0};
  g.supplyRng = randomStream(g.seed, 'silver-supply');
}
function prepareSilverRoom(g) {
  g.silverDrops = [];
  g.roomSupplyCount = 0;
  g.shots = [];
  g.silverTimers = {fork:1, ring:12, spiral:2, rain:20};
  g.silverPhase = 0;
  g.rainOffset = 0;
  g.lastSilverNotice = null;
  // Entrance pickups are visible, outside collection range of the unmoving starting position.
  for (const [x,y] of SUPPLY_PATHS[g.room]) placeSilver(g,point(x,y));
}
function placeSilver(g,p) {
  if (g.silverDrops.length < 44 && free(g.room,p,.16) && !g.silverDrops.some(d=>distance(d,p)<.35)) {
    const order = Object.keys(g.roster).length > 0 && g.orderRank < 6 && g.roomSupplyCount % 2 === 0;
    g.roomSupplyCount++;
    g.silverDrops.push({...copyPoint(p),born:g.tick,order});
    return true;
  }
  return false;
}
function scatterSilver(g) {
  // Drop a pair near the party's current route, with a small detour to pick it up.
  const angle = Math.atan2(g.facing.y,g.facing.x);
  for(let i=0;i<10;i++) {
    const a=angle+(g.supplyRng()-.5)*Math.PI*1.65, r=2.1+g.supplyRng()*1.7;
    const p=point(g.player.x+Math.cos(a)*r,g.player.y+Math.sin(a)*r);
    if(!visible(g.room,g.player,p,.18) || !placeSilver(g,p)) continue;
    placeSilver(g,point(p.x+Math.cos(a+.45)*.76,p.y+Math.sin(a+.45)*.76));
    return;
  }
}
function collectSilver(g) {
  if ((g.room===2 || g.tick<g.exitTick) && g.tick%420===240) scatterSilver(g);
  const supply=g.stance('supply');
  g.silverDrops=g.silverDrops.filter(drop=>{
    const dist=distance(drop,g.player);
    if(dist>(supply?2+2*supply.rank:(g.silver.count?1.42:.86)) || !visible(g.room,drop,g.player,.12))return true;
    const dir=to(drop,g.player), step=Math.min(dist,(supply?10:3.4+(1.42-dist)*4.8)*DT);
    drop.x+=dir.x*step;
    drop.y+=dir.y*step;
    if(distance(drop,g.player)>.35)return true;
    if(supply){
      for(const u of g.units)u.ready=g.tick;
      if(++supply.progress%3===0 && supply.rank===2)g.hp=Math.min(6,g.hp+1);
    }
    if (drop.order) {
      g.orderRank = Math.min(6,g.orderRank+1);
      for (const u of g.units) u.ready = g.tick;
      const names = g.units.map(u => PIECES[u.key].name).join(' · ');
      g.lastSilverNotice = {tick:g.tick,text:names+' 오더 +'+g.orderRank};
      effect(g,'shock',g.player,g.player,{range:1});
      return false;
    }
    const s=g.silver;
    s.count++;
    const next=SILVER_TIERS[s.tier+1];
    const burst=s.tier===6 && (s.count-SILVER_TIERS[6].need)%6===0;
    if(next && s.count>=next.need) {
      s.tier++;
      g.lastSilverNotice={tick:g.tick,text:'은식기 '+(s.tier+1)+'단계 · '+next.name};
      for(const key of Object.keys(g.silverTimers))g.silverTimers[key]=g.tick+1;
    } else if(burst) {
      s.bursts++;
      g.lastSilverNotice={tick:g.tick,text:'은식기 폭풍 · 추가 일제 사격'};
      silverRing(g,48,g.silverPhase);
    }
    s.pickups.push({room:g.room,tick:g.tick,tier:s.tier,count:s.count});
    effect(g,'silverPick',g.player,g.player,{end:g.tick+38});
    return false;
  });
}
function launchSilver(g,kind,x,y,a,speed,power,life,pierce,curve=0) {
  const shot={kind,x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,power,until:g.tick+life,
              left:pierce,hit:[],curve};
  g.shots.push(shot);
  g.silver.fired++;
}
function silverRing(g,count,phase) {
  for(let i=0;i<count;i++)launchSilver(g,'knife',g.player.x,g.player.y,phase+i*Math.PI*2/count,5.7,1,144,3);
}
function fireSilver(g) {
  const s=g.silver, spec=SILVER_TIERS[s.tier], t=g.silverTimers, p=g.player;
  if(s.tier===0)return;
  if(g.tick>=t.fork) {
    const target=sortedTargets(g,p,8)[0];
    if(target || s.tier>=3) {
      const dir=target?to(p,target):g.facing,angle=Math.atan2(dir.y,dir.x);
      for(let i=0;i<spec.forks;i++) {
        const spread=(i-(spec.forks-1)/2)*.145;
        launchSilver(g,'fork',p.x,p.y,angle+spread,8.6,1,103,2);
      }
      t.fork=g.tick+spec.forkTime;
    }
  }
  if(spec.ring && g.tick>=t.ring) {
    silverRing(g,spec.ring,g.silverPhase);
    g.silverPhase+=.36;
    t.ring=g.tick+spec.ringTime;
  }
  if(spec.spiral && g.tick>=t.spiral) {
    const angle=g.tick*.027;
    for(let i=0;i<spec.spiral;i++) {
      launchSilver(g,'spoon',p.x,p.y,angle+i*Math.PI*2/spec.spiral,4.7,1,135,2,i%2===0?.014:-.014);
    }
    t.spiral=g.tick+10;
  }
  if(spec.rain && g.tick>=t.rain) {
    // Stagger entries over the whole stage. Every visible blade sweeps a damaging path.
    g.rainOffset++;
    const side=g.rainOffset%2?1:-1;
    for(let i=0;i<spec.rain;i++) {
      const x=((i*7.13+g.rainOffset*2.73)%22)-1;
      const y=((i*2.43+g.rainOffset*1.72)%12.8)-.8;
      launchSilver(g,'rain',x,y,side>0?1.03:2.11,8.1,1,45,2);
    }
    t.rain=g.tick+(s.tier===6?12:24);
  }
}
function advanceSilver(g) {
  fireSilver(g);
  g.shots=g.shots.filter(q=>{
    if(g.tick>q.until)return false;
    const ox=q.x,oy=q.y;
    if(q.curve) {
      const c=Math.cos(q.curve),s=Math.sin(q.curve),vx=q.vx;
      q.vx=vx*c-q.vy*s; q.vy=vx*s+q.vy*c;
    }
    q.x+=q.vx*DT; q.y+=q.vy*DT;
    const dx=q.x-ox,dy=q.y-oy,len=dx*dx+dy*dy;
    for(const e of g.enemies) {
      if(e.hp<=0 || Math.abs(e.x-q.x)>.75 || Math.abs(e.y-q.y)>.75 || q.hit.includes(e.id))continue;
      const t=clamp(((e.x-ox)*dx+(e.y-oy)*dy)/len,0,1);
      if(Math.hypot(ox+t*dx-e.x,oy+t*dy-e.y)>e.radius+.13)continue;
      damage(g,e,q.power,true);
      q.hit.push(e.id);g.silver.hits++;
      if(--q.left===0)return false;
    }
    return q.x>-.8 && q.x<20.8 && q.y>-.8 && q.y<12.8;
  });
  g.silver.peak=Math.max(g.silver.peak,g.shots.length);
  g.stats.peakSilver=Math.max(g.stats.peakSilver||0,g.shots.length);
}
