// Fixed 60 Hz simulation. World units are metres. Rendering and input never draw random numbers.
const HZ = 60, DT = 1 / HZ, TURN_LINE = 'Your Move, My Lord.';
const ROOMS = [
{name:'현관홀', en:'ENTRANCE HALL', note:'중앙 탁자를 돌아 추격대를 따돌리세요.', blocks:[[9, 5, 2, 2, 'table']]},
{name:'서재 회랑', en:'LIBRARY GALLERY', note:'북쪽 우회로에서 돌진을 피하고 긴 복도로 추격대를 유인하세요.', blocks:[[0, 0, 20, 1, 'bookcase'], [4, 3, 12, 1.5, 'bookcase'], [0, 7.5, 20, 4.5, 'bookcase']]},
{name:'연회장', en:'GRAND SALOON', note:'두 탁자 사이로 돌진을 유도하세요. 멈춘 보스는 피해를 1.5배 받습니다.', blocks:[[6.5, 5, 2, 2, 'table'], [11.5, 5, 2, 2, 'table']]}
];
const PIECES = {
  finny:{
    name:'피니안',
    role:'좌측 호위',
    piece:'♘',
    en:'KNIGHT',
    color:'#a0b778',
    time:144,
    link:['bard'],
    command:'밀어내, 피니.',
    basic:'가까이 온 적에게 피해 9를 주고 1m 밀칩니다.',
    upgrade:'충격 반경 1.3 → 1.7m · 명령 밀치기 1 → 1.5m',
    effect:'시엘 주위에 충격을 가해 적을 밀칩니다.',
    formation:[0, -.4],
    skill:finny
  },
  meyrin:{
    name:'메이린',
    role:'후미 사격',
    piece:'♗',
    en:'BISHOP',
    color:'#c28f9c',
    time:120,
    link:['snake', 'lizzy'],
    command:'사선을 잡아.',
    basic:'뒤따르는 적을 먼저 노려 6m 사선 전체에 피해 14를 줍니다.',
    upgrade:'사선 폭 0.4 → 0.65m · 명령 0.25초 뒤 추가 사격',
    effect:'후방 우선으로 즉시 관통 사격합니다.',
    formation:[-1.4, 0],
    skill:meyrin
  },
  bard:{
    name:'바르도',
    role:'우측 후방',
    piece:'♖',
    en:'ROOK',
    color:'#d7a276',
    time:150,
    link:['finny'],
    command:'퇴로에 불을 놔.',
    basic:'뒤에 남은 불길이 0.5초마다 피해 3을 줍니다.',
    upgrade:'기본·명령 불길 지속 시간 2 → 3초',
    effect:'지나온 길 2m에 불길 세 개를 남깁니다.',
    formation:[-.56, .42],
    skill:bard
  },
  snake:{
    name:'스네이크',
    role:'좌측 후방',
    piece:'♞',
    en:'KNIGHT',
    color:'#93b3a4',
    time:168,
    link:['meyrin'],
    command:'발을 묶어.',
    basic:'뱀이 후방의 적 둘을 2초간 40% 늦춥니다.',
    upgrade:'기본 대상 2 → 3명 · 명령 감속 2 → 3초',
    effect:'4m 안의 적 셋을 50% 늦춥니다. 감속 중 관통 피해 +5.',
    formation:[-.64, -.48],
    skill:snake
  },
  lizzy:{
    name:'엘리자베스',
    role:'선두 쌍검',
    piece:'♕',
    en:'QUEEN',
    color:'#d2b372',
    time:96,
    link:['meyrin'],
    command:'정면을 부탁해.',
    basic:'쌍검으로 전방 100도 안의 적에게 피해 12를 줍니다.',
    upgrade:'기본 각도 100 → 140도 · 명령 2.3m, 피해 20',
    effect:'전방 140도·2m 안의 적에게 피해 16을 줍니다.',
    formation:[.8, 0],
    skill:lizzy
  }
};
// Reserved definitions share the same skill interface. The manor trial draws only its five playable pieces.
const RESERVE_PIECES = {
  lau: {name:'라우', role:'측면 표식', formation:[0, 1], time:180, available:false, skill:markElite},
  grell: {name:'그렐', role:'표식 유격', formation:[0, -1], time:156, available:false, skill:markedRush},
  soma: {name:'소마', role:'중앙 지원', formation:[0, 0], time:240, available:false, skill:encourage},
  agni: {name:'아그니', role:'전위 연타', formation:[.5, .49], time:108, available:false, skill:flurry}
};
Object.assign(PIECES, RESERVE_PIECES);
const trialKeys = () => Object.keys(PIECES).filter(k => PIECES[k].available !== false && typeof PIECES[k].skill === 'function');
function markElite(g, u, command, probe) {
  const priority = e => e.kind === 'boss'?0:e.kind === 'elite'?1:2;
  const target = sortedTargets(g, u, 4).sort((a, b) => priority(a) - priority(b))[0];
  if (!target)return false;
  if (!probe) {
    target.markUntil = g.tick + (u.level === 2?240:180);
    effect(g, 'shock', target, target, {range:.32});
  }
  return true;
}
function markedRush(g, u, command, probe) {
  const priority = e => e.markUntil > g.tick?0:e.kind === 'boss' || e.kind === 'elite'?1:2;
  const target = sortedTargets(g, u, u.level === 2?5:4).sort((a, b) => priority(a) - priority(b))[0];
  if (!target)return false;
  if (!probe) {
    effect(g, 'silver', u, target);
    damage(g, target, 18);
  }
  return true;
}
function flurry(g, u, command, probe) {
  const target = sortedTargets(g, u, 1.5)[0];
  if (!target)return false;
  if (!probe) {
    const strike = () => {
      if (target.hp > 0) {
        damage(g, target, 4);
        effect(g, 'silver', u, target);
      }
    };
    strike();
    for (let i = 1;i < (u.level === 2?4:3);i++)g.pending.push({due:g.tick + 6 * i, run:strike});
  }
  return true;
}
function encourage(g, u, command, probe, triggerExtra) {
  const attackers = g.units.filter(other => other !== u && other.key !== 'soma' && g.invoke(other.key, false, true))
  .sort((a, b) => distance(u, a) - distance(u, b));
  const chosen = attackers.find(other => other.key === 'agni' && distance(u, other) <= 1.5) || attackers[0];
  if (chosen)return probe || triggerExtra(chosen.key);
  const enemy = sortedTargets(g, g.player, 5)[0];
  if (!enemy)return false;
  if (!probe) {
    damage(g, enemy, 7);
    effect(g, 'silver', g.player, enemy);
  }
  return true;
}
const COMMON = {
guard:{name:'엄호해', effect:'2초 안에 접촉 한 번을 막습니다. 막은 뒤 1.25초간 무적입니다.'},
open:{name:'길을 열어', effect:'전방 90도·2m 안의 적에게 피해 5를 주고 0.8m 밀칩니다.'}
};
const SCHOOLS = {
  hunt: {name:'사냥', cards:['snare','quarry']},
  siege: {name:'화공', cards:['fireline','furnace']},
  escort: {name:'호위', cards:['screen','rally']}
};
const TACTICS = {
  snare:{name:'발을 묶어', effect:'6m 안의 적 넷을 5초간 45% 감속합니다. 메이린의 관통탄이 추가 피해를 줍니다.'},
  quarry:{name:'사냥감을 몰아', effect:'8m 안의 적을 6초간 감속하고 표식으로 받는 피해를 30% 높입니다.'},
  fireline:{name:'퇴로를 태워', effect:'최근 이동 경로 3m에 5초간 불길을 남깁니다. 피니안으로 적을 밀어 넣을 수 있습니다.'},
  furnace:{name:'불길을 넓혀', effect:'현재 불길을 4초 연장하고 시엘 주위 네 방향에 6초간 불길을 놓습니다.'},
  screen:{name:'대열을 지켜', effect:'5초간 접촉 한 번을 막고 모든 사용인의 기본 공격을 즉시 준비합니다.'},
  rally:{name:'반격을 개시해', effect:'5초간 접촉 한 번을 막고 모든 사용인에게 즉시 고유 명령을 내립니다. 1초 뒤 한 번 더 명령합니다.'}
};
function castTactic(g,key) {
  if (key === 'snare' || key === 'quarry') {
    const marked = key === 'quarry';
    for (const e of sortedTargets(g,g.player,marked?8:6).slice(0,marked?Infinity:4)) {
      e.slows.push({rate:.45,end:g.tick+(marked?360:300)});
      if (marked) e.markUntil = Math.max(e.markUntil||0,g.tick+360);
      effect(g,'snake',g.player,e);
    }
  } else if (key === 'fireline' || key === 'furnace') {
    const ring = key === 'furnace';
    if (ring) for (const fire of g.fires) fire.end += 240;
    for (let i=0;i<4;i++) {
      const p = ring ? point(g.player.x+Math.cos(i*Math.PI/2),g.player.y+Math.sin(i*Math.PI/2)) : trailAt(g,i);
      g.fires.push({...copyPoint(free(g.room,p,.1)?p:g.player),born:g.tick,end:g.tick+(ring?360:300)});
    }
  } else {
    g.shield = g.tick+300;
    effect(g,'guard',g.player,g.player,{range:1});
    if (key === 'screen') for (const u of g.units) u.ready=g.tick;
    else {
      const volley = () => { for (const u of g.units) g.invoke(u.key,true); };
      volley();
      g.pending.push({due:g.tick+60,run:volley});
    }
  }
}

const ENEMY = {chaser:[18, 1.15, .22], elite:[36, .9, .29], charger:[25, 1.15, .24], boss:[160, 1.05, .38]};
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const point = (x, y) => ({x, y});
const copyPoint = p => point(p.x, p.y);
const unit = (x, y) => {
  const n = Math.hypot(x, y) || 1;
  return point(x / n, y / n);
};
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const to = (a, b) => unit(b.x - a.x, b.y - a.y);
const dot = (a, b) => a.x * b.x + a.y * b.y;
function randomStream(seed, label) {
  let state = 2166136261;
  for (const ch of String(seed) + '/' + label) state = Math.imul(state ^ ch.charCodeAt(0), 16777619) >>> 0;
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let n = state;
    n = Math.imul(n ^ (n >>> 15), n | 1);
    n ^= n + Math.imul(n ^ (n >>> 7), n | 61);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1;i > 0;i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function free(room, p, r) {
  if (p.x < r || p.x > 20 - r || p.y < r || p.y > 12 - r)return false;
  return ROOMS[room].blocks.every(([x, y, w, h]) => Math.hypot(p.x - clamp(p.x, x, x + w), p.y - clamp(p.y, y, y + h)) >= r - 1e-8);
}
// Small steps preserve circular collisions during knockback as well as normal movement.
function travel(room, p, dx, dy, r) {
  const count = Math.max(1, Math.ceil(Math.hypot(dx, dy) / .1));
  let hit = false;
  for (let i = 0;i < count;i++) {
    if (free(room, point(p.x + dx / count, p.y), r))p.x += dx / count;else hit = true;
    if (free(room, point(p.x, p.y + dy / count), r))p.y += dy / count;else hit = true;
  }
  return hit;
}
function visible(room, a, b, r) {
  const count = Math.ceil(distance(a, b) / .18);
  for (let i = 1;i <= count;i++)if (!free(room, point(a.x + (b.x - a.x) * i / count, a.y + (b.y - a.y) * i / count), r))return false;
  return true;
}
const gridPoint = id => point((id % 40) * .5 + .25, Math.floor(id / 40) * .5 + .25);
const grids = new Map();
function navigate(room, a, b, r) {
  if (visible(room, a, b, r))return b;
  const key = room + '/' + r;
  if (!grids.has(key)) {
    const ok = Array.from({length:960}, (_, i) => free(room, gridPoint(i), r));
    const edges = ok.map((isOpen, i) => !isOpen?[]:[i - 40, i % 40 === 39?-1:i + 1, i + 40, i % 40 === 0?-1:i - 1].filter(j => ok[j] && visible(room, gridPoint(i), gridPoint(j), r)));
    grids.set(key, {ok, edges, fields:new Map()});
  }
  const g = grids.get(key);
  function cell(p) {
    const i = clamp(Math.floor(p.y * 2), 0, 23) * 40 + clamp(Math.floor(p.x * 2), 0, 39);
    if (g.ok[i])return i;
    let best = -1, d = Infinity;
    g.ok.forEach((v, j) => {
      if (v && distance(p, gridPoint(j)) < d) {
        best = j;
        d = distance(p, gridPoint(j));
      }
    });
    return best;
  }
  const start = cell(a), end = cell(b);
  if (!g.fields.has(end)) {
    const field = new Int16Array(960).fill(-1), q = [end];
    field[end] = 0;
    for (let i = 0;i < q.length;i++)for (const j of g.edges[q[i]])if (field[j] === -1) {
      field[j] = field[q[i]] + 1;
      q.push(j);
    }
    if (g.fields.size > 100)g.fields.clear();
    g.fields.set(end, field);
  }
  const d = g.fields.get(end);
  let id = start;
  for (let i = 0;i < 8 && id !== end;i++) {
    const next = g.edges[id].find(j => d[j] === d[id] - 1 && d[j] >= 0);
    if (next === undefined || !visible(room, a, gridPoint(next), r))break;
    id = next;
  }
  return gridPoint(id);
}
function trailAt(g, back) {
  const t = g.trail;
  let last = t[t.length - 1];
  for (let i = t.length - 2;i >= 0;i--) {
    const p = t[i], d = distance(last, p);
    if (d >= back && d)return point(last.x + (p.x - last.x) * back / d, last.y + (p.y - last.y) * back / d);
    back -= d;
    last = p;
  }
  return copyPoint(last);
}
function station(g, id) {
  const [forward, side] = PIECES[id].formation, p = g.player, f = g.facing;
  const base = forward < 0?trailAt(g, -forward):point(p.x + forward * f.x, p.y + forward * f.y);
  const dest = point(base.x - side * f.y, base.y + side * f.x);
  if (free(g.room, dest, .17))return dest;
  let best = p, d = Infinity;
  for (const a of g.trail)if (free(g.room, a, .17) && distance(a, dest) < d) {
    best = a;
    d = distance(a, dest);
  }
  return best;
}
function sortedTargets(g, p, range, pred = () => true) {
  return g.enemies.filter(e => e.hp > 0 && distance(e, p) <= range + 1e-8 && pred(e)).sort((a, b) => distance(a, p) - distance(b, p) || a.id - b.id);
}
function sector(g, p, range, degrees) {
  return sortedTargets(g, p, range, e => distance(e, p) < 1e-8 || dot(to(p, e), g.facing) >= Math.cos(degrees * Math.PI / 360) - 1e-8);
}
function effect(g, type, a, b, attr = {}) {
  g.effects.push({type, a:copyPoint(a), b:copyPoint(b), start:g.tick, end:g.tick + 22, ...attr});
}
function slowAt(g, e) {
  return Math.max(0, ...e.slows.filter(s => s.end > g.tick).map(s => s.rate));
}
function damage(g, e, amount, quiet = false) {
  if (e.hp <= 0)return;
  const value = amount * (e.markUntil > g.tick?1.3:1) * (e.kind === 'boss' && e.mode === 'rest'?1.5:1);
  e.hp -= value;
  e.flash = g.tick + 6;
  if (!quiet)effect(g, 'number', e, e, {value, end:g.tick + 29});
}
function pushAway(g, e, p, amount) {
  const dir = distance(e, p) < .0001?g.facing:to(p, e);
  travel(g.room, e, dir.x * amount, dir.y * amount, e.radius);
}
function meyrin(g, u, command, probe = false) {
  const list = sortedTargets(g, u, 6), rear = list.find(e => dot(to(u, e), g.facing) < 0), target = rear || list[0];
  if (!target)return false;
  if (probe)return true;
  const direction = distance(target, u) < 1e-8?g.facing:to(u, target), width = (u.level === 2?.65:.4) + g.orderRank*.12;
  function shoot(dir, followUp = false) {
    u.bracedUntil = g.tick + 9;
    let hits = 0;
    for (const e of g.enemies) {
      if (e.hp <= 0)continue;
      const dx = e.x - u.x, dy = e.y - u.y, along = dx * dir.x + dy * dir.y;
      if (along >= 0 && along <= 6 && Math.abs(dx * dir.y - dy * dir.x) <= width / 2 + 1e-8) {
        damage(g, e, 14 + 4*g.orderRank + (slowAt(g, e) > 0?5:0));
        hits++;
      }
    }
    g.log.beams.push({room:g.room, tick:g.tick, hits, command});
    effect(g, 'beam', u, point(u.x + dir.x * 6, u.y + dir.y * 6), {width, hits, followUp});
  }
  shoot(direction);
  if (command && u.level === 2)g.pending.push({due:g.tick + 15, run:() => shoot(direction, true)});
  return true;
}
function finny(g, u, command, probe = false) {
  const origin = command?g.player:u, range = (u.level === 2?1.7:1.3) + .17*g.orderRank, targets = sortedTargets(g, origin, range);
  if (!targets.length)return false;
  if (probe)return true;
  targets.forEach(e => {
    damage(g, e, 9 + 4*g.orderRank);
    pushAway(g, e, origin, command && u.level === 2?1.5:1);
  });
  effect(g, 'shock', origin, origin, {range});
  return true;
}
function bard(g, u, command, probe = false) {
  if (probe)return true;
  for (const p of command?[trailAt(g, 0), trailAt(g, 1), trailAt(g, 2)]:[u]) {
    g.fires.push({...copyPoint(p), born:g.tick, end:g.tick + (u.level === 2?180:120)});
  }
  return true;
}
function snake(g, u, command, probe = false) {
  const targets = sortedTargets(g, u, (command?4:3) + .25*g.orderRank, e => command || dot(to(u, e), g.facing) <= 0).slice(0, (command || u.level === 2?3:2) + Math.ceil(g.orderRank/2));
  if (!targets.length)return false;
  if (probe)return true;
  for (const e of targets) {
    e.slows.push({rate:(command?.5:.4) + .04*g.orderRank, end:g.tick + (command && u.level === 2?180:120)});
    effect(g, 'snake', u, e);
  }
  return true;
}
function lizzy(g, u, command, probe = false) {
  const radius = (command?(u.level === 2?2.3:2):1.3) + .16*g.orderRank, degrees = command || u.level === 2?140:100;
  const targets = sector(g, u, radius, degrees);
  if (!targets.length)return false;
  if (probe)return true;
  targets.forEach(e => damage(g, e, (command?(u.level === 2?20:16):12) + 4*g.orderRank));
  effect(g, 'slash', u, g.facing, {range:radius, degrees});
  return true;
}
function wavePlan(room) {
  const events = [];
  function band(start, end, interval, count, side) {
    for (let tick = start * HZ, i = 0;tick < end * HZ;tick += Math.round(interval * HZ), i++)
    events.push({at:tick, kind:'chaser', side:side === 'alt'?(i % 2?'W':'E'):side, count});
  }
  if (room === 0) {
    band(0, 20, 2, 1, 'W');
    band(20, 45, 1.5, 1, 'alt');
    band(45, 60, 1, 1, 'E');
    events.push({at:1800, kind:'elite', side:'W', count:1});
  }
  if (room === 1) {
    band(0, 20, 1.5, 1, 'W');
    band(20, 45, 1, 1, 'alt');
    band(45, 60, 1.2, 2, 'E');
    for (const t of [25, 40, 52])events.push({at:t * HZ, kind:'charger', side:'N', count:1});
  }
  return events.sort((a, b) => a.at - b.at || Number(b.kind !== 'chaser') - Number(a.kind !== 'chaser'));
}
class Game{
  constructor(seed = '1889', commands = true) {
    this.seed = String(seed);
    this.commands = commands;
    this.hp = 6;
    this.schoolPicks = [];
    this.roster = {};
    this.deck = [];
    this.cardId = 0;
    this.choice = 0;
    this.resultCount = 0;
    this.kills = 0;
    initSilver(this);
    this.rng = {wave:randomStream(seed, 'wave'), reward:randomStream(seed, 'reward'), deck:randomStream(seed, 'deck')};
    this.log = {rooms:[], picks:[], hands:[], commands:[], beams:[], spawns:[]};
    for (const key of ['guard', 'guard', 'open', 'open'])this.addCard(key);
    this.enter(0);
  }
  addCard(key) {
    this.deck.push({id:++this.cardId, key, level:1});
  }
  enter(room) {
    this.room = room;
    this.tick = 0;
    this.phase = 'fight';
    this.door = false;
    this.ended = false;
    this.player = point(2, 6);
    this.facing = point(1, 0);
    this.walk = 0;
    this.cool = 0;
    this.immune = 0;
    this.shield = 0;
    this.trail = Array.from({length:18}, (_, i) => point(1.15 + i * .05, 6));
    this.trail.push(copyPoint(this.player));
    this.enemies = [];
    this.warnings = [];
    this.items = [];
    prepareSilverRoom(this);
    this.fires = [];
    this.effects = [];
    this.pending = [];
    this.enemyId = 0;
    this.units = Object.entries(this.roster).map(([key, level]) => ({key, level, ...station(this, key), ready:0}));
    this.draw = shuffle(this.deck.map(c => ({...c})), this.rng.deck);
    if (this.schoolPicks.length) {
      const school=this.schoolPicks.at(-1);
      const newest=SCHOOLS[school].cards[this.schoolPicks.filter(k=>k===school).length-1];
      const index=this.draw.findIndex(c=>c.key===newest);
      if(index>=0)this.draw.push(this.draw.splice(index,1)[0]);
    }
    this.discard = [];
    this.hand = [];
    this.candidates = [];
    this.waves = wavePlan(room);
    this.waveIndex = 0;
    this.nextHand = 720;
    this.stats = {room, hits:0, elapsed:0};
    this.log.rooms.push(this.stats);
    if (room === 2) {
      this.enemy('boss', 16, 6);
      if (this.commands)this.deal();
    }
  }
  enemy(kind, x, y) {
    const [hp, speed, radius] = ENEMY[kind], e = {id:++this.enemyId, kind, x, y, hp, max:hp, speed, radius, mode:'chase', until:kind === 'boss'?this.tick + 180:0, dx:1, dy:0, slows:[], fireReady:0, flash:0};
    this.enemies.push(e);
    return e;
  }
  deal() {
    if (this.phase !== 'fight')return;
    for (let i = 0;i < 2;i++) {
      if (!this.draw.length) {
        this.draw = shuffle(this.discard, this.rng.deck);
        this.discard = [];
      }
      if (this.draw.length)this.hand.push(this.draw.pop());
    }
    this.phase = 'hand';
    this.choice++;
    this.log.hands.push({room:this.room, tick:this.tick, cards:this.hand.map(c => c.key), ids:this.hand.map(c => c.id)});
  }
  invoke(key, command, probe = false, context = {extra:false}) {
    // Expansion skills may ask for an extra cast using this guarded dispatcher.
    const u = this.units.find(u => u.key === key);
    if (!u)return false;
    const triggerExtra = other => context.extra?false:this.invoke(other, false, false, {extra:true});
    return PIECES[key].skill(this, u, command, probe, triggerExtra);
  }
  can(card) {
    if (TACTICS[card.key]) {
      if (card.key === 'snare' || card.key === 'quarry')return sortedTargets(this,this.player,card.key==='snare'?6:8).length>0;
      return true;
    }
    if (card.key === 'guard')return true;
    if (card.key === 'open')return sector(this, this.player, 2, 90).length > 0;
    return this.invoke(card.key, true, true);
  }
  order(id, token = this.choice) {
    if (this.phase !== 'hand' || token !== this.choice)return false;
    const card = this.hand.find(c => c.id === id);
    if (id !== null && (!card || !this.can(card)))return false;
    if (card) {
      if (TACTICS[card.key])castTactic(this,card.key);
      else if (card.key === 'guard') {
        this.shield = this.tick + 120;
        effect(this, 'guard', this.player, this.player, {range:1});
      }
      else if (card.key === 'open') {
        for (const e of sector(this, this.player, 2, 90)) {
          damage(this, e, 5);
          pushAway(this, e, this.player, .8);
        }
        effect(this, 'open', this.player, this.facing, {range:2, degrees:90});
      }
      else this.invoke(card.key, true);
      this.log.commands.push({room:this.room, tick:this.tick, key:card.key});
    }
    this.discard.push(...this.hand);
    this.hand = [];
    this.phase = 'fight';
    this.resolveDeaths();
    return true;
  }
  reward() {
    if (this.phase !== 'fight')return;
    const rng = this.rng.reward;
    if (this.room === 0)
    this.candidates = shuffle(['finny', 'meyrin', 'bard'], rng);
    else{
      const owned = Object.keys(this.roster)[0], others = trialKeys().filter(k => !this.roster[k]);
      const partner = shuffle(PIECES[owned].link.filter(k => others.includes(k)), rng)[0] || shuffle(others, rng)[0];
      const extra = shuffle(others.filter(k => k !== partner), rng)[0];
      this.candidates = shuffle([owned, partner, extra], rng);
    }
    this.phase = 'reward';
    this.choice++;
  }
  choose(key, token = this.choice, school = null) {
    if (this.phase !== 'reward' || token !== this.choice || !this.candidates.includes(key))return false;
    if (school !== null) {
      if (!this.commands || !Object.hasOwn(SCHOOLS,school))return false;
      const tier=this.schoolPicks.includes(school)?1:0;
      const slot=this.deck.find(c=>c.key===(this.schoolPicks.length?'open':'guard'));
      if (!slot)return false;
      slot.key=SCHOOLS[school].cards[tier];
      this.schoolPicks.push(school);
    }
    if (this.roster[key]) {
      this.roster[key] = 2;
      this.deck.find(c => c.key === key).level = 2;
    }
    else{
      this.roster[key] = 1;
      this.addCard(key);
    }
    this.log.picks.push({room:this.room, key, level:this.roster[key]});
    this.enter(this.room + 1);
    return true;
  }
  finish(outcome) {
    if (this.ended)return;
    this.ended = true;
    this.phase = outcome;
    this.resultCount++;
  }
  resolveDeaths() {
    for (const e of this.enemies.filter(e => e.hp <= 0)) {
      this.kills++;
      effect(this, 'death', e, e);
      if (e.kind === 'elite')this.items.push(copyPoint(e));
      if (e.kind !== 'boss' && (e.kind !== 'chaser' || this.kills % 3 === 0))placeSilver(this,e);
      if (e.kind === 'boss')this.finish('win');
    }
    this.enemies = this.enemies.filter(e => e.hp > 0);
  }
  schedule(group) {
    const cap = this.room === 2?9:22;
    for (let i = 0;i < group.count;i++) {
      // Consume a fixed sample budget even for capped or unsafe entries.
      const draws = Array.from({length:24}, () => this.rng.wave());
      if (this.enemies.length + this.warnings.length >= cap)continue;
      let location;
      for (const v of draws) {
        const p = group.side === 'N'?point(.5 + v * 19, 1.42):point(group.side === 'E'?19.6:.4, .45 + v * 11.1);
        if (free(this.room, p, ENEMY[group.kind][2]) && distance(this.player, p) >= 2) {
          location = p;
          break;
        }
      }
      if (location)this.warnings.push({...location, kind:group.kind, end:this.tick + 36});
    }
  }
  advanceWaves() {
    if (this.room === 2) {
      if (this.tick % 480 === 0)this.schedule({kind:'chaser', side:(this.tick / 480) % 2?'E':'W', count:2});
    }else if (this.tick < 3600) {
      while (this.waveIndex < this.waves.length && this.waves[this.waveIndex].at <= this.tick)this.schedule(this.waves[this.waveIndex++]);
    }
    this.warnings = this.warnings.filter(w => {
      if (this.room !== 2 && this.tick >= 3600)return false;
      if (this.tick < w.end)return true;
      if (distance(this.player, w) >= 2) {
        this.enemy(w.kind, w.x, w.y);
        this.log.spawns.push([this.tick, w.kind, w.x, w.y]);
      }
      return false;
    });
  }
  moveEnemy(e) {
    e.slows = e.slows.filter(s => s.end > this.tick);
    const boss = e.kind === 'boss', charging = boss || e.kind === 'charger';
    if (charging) {
      if (e.mode === 'rest' && this.tick >= e.until) {
        e.mode = 'chase';
        e.until = this.tick + 180;
      }
      if (e.mode === 'chase' && this.tick >= e.until && (boss || distance(e, this.player) <= 4)) {
        const dir = to(e, this.player);
        e.dx = dir.x;
        e.dy = dir.y;
        e.mode = 'warn';
        e.until = this.tick + (boss?54:48);
      }else if (e.mode === 'warn' && this.tick >= e.until) {
        e.mode = 'dash';
        e.until = this.tick + (boss?39:27);
      }
      if (e.mode === 'dash') {
        const hit = this.tick < e.until && travel(this.room, e, e.dx * 5 * DT, e.dy * 5 * DT, e.radius);
        if (hit || this.tick >= e.until) {
          e.mode = 'rest';
          e.until = this.tick + (boss?90:66);
        }
        return;
      }
      if (e.mode !== 'chase')return;
    }
    const dest = navigate(this.room, e, this.player, e.radius), dir = to(e, dest), d = Math.min(distance(e, dest), e.speed * (1 - slowAt(this, e)) * DT);
    travel(this.room, e, dir.x * d, dir.y * d, e.radius);
  }
  moveParty(input) {
    const n = Math.hypot(input.x, input.y), p = this.player;
    if (n > .001) {
      const prev = copyPoint(p), dir = unit(input.x, input.y);
      this.facing = dir;
      travel(this.room, p, dir.x * 3.2 * DT * Math.min(n, 1), dir.y * 3.2 * DT * Math.min(n, 1), .22);
      this.walk += distance(prev, p);
      if (distance(p, this.trail[this.trail.length - 1]) > .018) {
        this.trail.push(copyPoint(p));
        if (this.trail.length > 400)this.trail.shift();
      }
    }
    for (const u of this.units) {
      if (u.bracedUntil > this.tick)continue;
      const dest = navigate(this.room, u, station(this, u.key), .17), dir = to(u, dest), d = Math.min(4.5 * DT, distance(u, dest));
      travel(this.room, u, dir.x * d, dir.y * d, .17);
    }
  }
  allied() {
    if (this.tick >= this.cool) {
      const target = sortedTargets(this, this.player, 5)[0];
      if (target) {
        damage(this, target, 7);
        effect(this, 'silver', this.player, target);
        this.cool = this.tick + 48;
      }
    }
    for (const u of this.units)if (this.tick >= u.ready && this.invoke(u.key, false))u.ready = this.tick + Math.round(PIECES[u.key].time/(1 + .15*this.orderRank));
    const due = this.pending.filter(t => t.due <= this.tick);
    this.pending = this.pending.filter(t => t.due > this.tick);
    due.forEach(t => t.run());
    this.fires = this.fires.filter(f => f.end >= this.tick);
    for (const e of this.enemies) {
      if (e.hp > 0 && this.tick >= e.fireReady && this.fires.some(f => this.tick > f.born && (this.tick - f.born) % 30 === 0 && distance(e, f) <= .8 + .14*this.orderRank)) {
        damage(this, e, 3 + this.orderRank);
        e.fireReady = this.tick + 30;
      }
    }
  }
  step(input = point(0, 0)) {
    if (this.phase !== 'fight')return;
    this.tick++;
    this.stats.elapsed = this.tick;
    this.advanceWaves();
    this.moveParty(input);
    for (const e of this.enemies)this.moveEnemy(e);
    this.effects = this.effects.filter(f => f.end > this.tick);
    this.allied();
    advanceSilver(this);
    this.resolveDeaths();
    if (this.ended)return;
    if (this.tick >= this.immune && this.enemies.some(e => distance(e, this.player) <= .22 + e.radius)) {
      this.immune = this.tick + 75;
      if (this.shield > this.tick)
      this.shield = 0;else{
        this.hp--;
        this.stats.hits++;
        effect(this, 'hurt', this.player, this.player);
      }
      if (this.hp === 0) {
        this.finish('loss');
        return;
      }
    }
    collectSilver(this);
    this.items = this.items.filter(p => {
      if (distance(this.player, p) > .6)return true;
      this.hp = Math.min(6, this.hp + 1);
      effect(this, 'heal', p, p);
      return false;
    });
    if (this.room !== 2 && this.tick >= 3600) {
      this.door = true;
      if (distance(this.player, point(19, 6)) <= .55) {
        this.reward();
        return;
      }
    }
    if (this.commands && this.tick === this.nextHand) {
      this.nextHand = this.room === 2?this.tick + 1500:this.tick === 720?1800:this.tick === 1800?2880:Infinity;
      this.deal();
    }
  }
}
function screenInput(x, y, iso) {
  if (!iso)return point(x, y);
  const n = Math.min(1, Math.hypot(x, y)), dir = unit(x + 2 * y, 2 * y - x);
  return point(dir.x * n, dir.y * n);
}
