// Fixed 60 Hz simulation. World units are metres. Rendering and input never draw random numbers.
const HZ = 60, DT = 1 / HZ, TURN_LINE = 'Your Move, My Lord.';
const ROOMS = [
{name:'현관홀', en:'ENTRANCE HALL', note:'중앙 탁자를 돌아 추격대를 따돌리세요.', blocks:[[9, 5, 2, 2, 'table']]},
{name:'서재 회랑', en:'LIBRARY GALLERY', note:'북쪽 우회로에서 돌진을 피하고 긴 복도로 추격대를 유인하세요.', blocks:[[0, 0, 20, 1, 'bookcase'], [4, 3, 12, 1.5, 'bookcase'], [0, 7.5, 20, 4.5, 'bookcase']]},
{name:'연회장', en:'GRAND SALOON', note:'두 탁자 사이로 돌진을 유도하세요. 멈춘 보스는 피해를 1.5배 받습니다.', blocks:[[6.5, 5, 2, 2, 'table'], [11.5, 5, 2, 2, 'table']]}
];
const PIECES = {
  finny:{
    name:'피니안',
    role:'좌측 호위',
    piece:'♘',
    en:'KNIGHT',
    color:'#a0b778',
    time:144,
    link:['bard'],
    command:'밀어내, 피니.',
    basic:'가까이 온 적에게 피해 9를 주고 1m 밀칩니다.',
    upgrade:'충격 반경 1.3 → 1.7m · 명령 밀치기 1 → 1.5m',
    effect:'시엘 주위에 충격을 가해 적을 밀칩니다.',
    formation:[0, -.4],
    skill:finny
  },
  meyrin:{
    name:'메이린',
    role:'후미 사격',
    piece:'♗',
    en:'BISHOP',
    color:'#c28f9c',
    time:120,
    link:['snake', 'lizzy'],
    command:'사선을 잡아.',
    basic:'뒤따르는 적을 먼저 노려 6m 사선 전체에 피해 14를 줍니다.',
    upgrade:'사선 폭 0.4 → 0.65m · 명령 0.25초 뒤 추가 사격',
    effect:'후방 우선으로 즉시 관통 사격합니다.',
    formation:[-1.4, 0],
    skill:meyrin
  },
  bard:{
    name:'바르도',
    role:'우측 후방',
    piece:'♖',
    en:'ROOK',
    color:'#d7a276',
    time:150,
    link:['finny'],
    command:'퇴로에 불을 놔.',
    basic:'뒤에 남은 불길이 0.5초마다 피해 3을 줍니다.',
    upgrade:'기본·명령 불길 지속 시간 2 → 3초',
    effect:'지나온 길 2m에 불길 세 개를 남깁니다.',
    formation:[-.56, .42],
    skill:bard
  },
  snake:{
    name:'스네이크',
    role:'좌측 후방',
    piece:'♞',
    en:'KNIGHT',
    color:'#93b3a4',
    time:168,
    link:['meyrin'],
    command:'발을 묶어.',
    basic:'뱀이 후방의 적 둘을 2초간 40% 늦춥니다.',
    upgrade:'기본 대상 2 → 3명 · 명령 감속 2 → 3초',
    effect:'4m 안의 적 셋을 50% 늦춥니다. 감속 중 관통 피해 +5.',
    formation:[-.64, -.48],
    skill:snake
  },
  lizzy:{
    name:'엘리자베스',
    role:'선두 쌍검',
    piece:'♕',
    en:'QUEEN',
    color:'#d2b372',
    time:96,
    link:['meyrin'],
    command:'정면을 부탁해.',
    basic:'쌍검으로 전방 100도 안의 적에게 피해 12를 줍니다.',
    upgrade:'기본 각도 100 → 140도 · 명령 2.3m, 피해 20',
    effect:'전방 140도·2m 안의 적에게 피해 16을 줍니다.',
    formation:[.8, 0],
    skill:lizzy
  }
};
// Reserved definitions share the same skill interface. The manor trial draws only its five playable pieces.
const RESERVE_PIECES = {
  lau: {name:'라우', role:'측면 표식', formation:[0, 1], time:180, available:false, skill:markElite},
  grell: {name:'그렐', role:'표식 유격', formation:[0, -1], time:156, available:false, skill:markedRush},
  soma: {name:'소마', role:'중앙 지원', formation:[0, 0], time:240, available:false, skill:encourage},
  agni: {name:'아그니', role:'전위 연타', formation:[.5, .49], time:108, available:false, skill:flurry}
};
Object.assign(PIECES, RESERVE_PIECES);
const trialKeys = () => Object.keys(PIECES).filter(k => PIECES[k].available !== false && typeof PIECES[k].skill === 'function');
function markElite(g, u, command, probe) {
  const priority = e => e.kind === 'boss'?0:e.kind === 'elite'?1:2;
  const target = sortedTargets(g, u, 4).sort((a, b) => priority(a) - priority(b))[0];
  if (!target)return false;
  if (!probe) {
    target.markUntil = g.tick + (u.level === 2?240:180);
    effect(g, 'shock', target, target, {range:.32});
  }
  return true;
}
function markedRush(g, u, command, probe) {
  const priority = e => e.markUntil > g.tick?0:e.kind === 'boss' || e.kind === 'elite'?1:2;
  const target = sortedTargets(g, u, u.level === 2?5:4).sort((a, b) => priority(a) - priority(b))[0];
  if (!target)return false;
  if (!probe) {
    effect(g, 'silver', u, target);
    damage(g, target, 18);
  }
  return true;
}
function flurry(g, u, command, probe) {
  const target = sortedTargets(g, u, 1.5)[0];
  if (!target)return false;
  if (!probe) {
    const strike = () => {
      if (target.hp > 0) {
        damage(g, target, 4);
        effect(g, 'silver', u, target);
      }
    };
    strike();
    for (let i = 1;i < (u.level === 2?4:3);i++)g.pending.push({due:g.tick + 6 * i, run:strike});
  }
  return true;
}
function encourage(g, u, command, probe, triggerExtra) {
  const attackers = g.units.filter(other => other !== u && other.key !== 'soma' && g.invoke(other.key, false, true))
  .sort((a, b) => distance(u, a) - distance(u, b));
  const chosen = attackers.find(other => other.key === 'agni' && distance(u, other) <= 1.5) || attackers[0];
  if (chosen)return probe || triggerExtra(chosen.key);
  const enemy = sortedTargets(g, g.player, 5)[0];
  if (!enemy)return false;
  if (!probe) {
    damage(g, enemy, 7);
    effect(g, 'silver', g.player, enemy);
  }
  return true;
}
const COMMON = {
guard:{name:'엄호해', effect:'2초 안에 접촉 한 번을 막습니다. 막은 뒤 1.25초간 무적입니다.'},
open:{name:'길을 열어', effect:'전방 90도·2m 안의 적에게 피해 5를 주고 0.8m 밀칩니다.'}
};
const SCHOOLS = {
  chain:{name:'연쇄',cards:['spark','cascade']},
  ram:{name:'격돌',cards:['shove','crush']},
  cull:{name:'추격',cards:['pursue','finishOff']},
  bind:{name:'포박',cards:['net','tighten']},
  lure:{name:'유인',cards:['bait','ambush']},
  clock:{name:'시한',cards:['delay','salvo']},
  march:{name:'기동',cards:['stride','breakout']},
  bastion:{name:'진지',cards:['hold','citadel']},
  supply:{name:'보급',cards:['retrieve','reserve']},
  echo:{name:'협공',cards:['relay','chorus']},
  hunt: {name:'사냥', cards:['snare','quarry']},
  siege: {name:'화공', cards:['fireline','furnace']},
  escort: {name:'호위', cards:['screen','rally']}
};
const TACTICS = {
  spark:{name:'도화선에 불을 붙여',effect:'8초간 적 처치 시 반경 2m에 피해 9. 폭발로 쓰러진 적도 폭발합니다.'},
  cascade:{name:'끝까지 터뜨려',effect:'12초간 처치 폭발의 반경이 3m, 피해가 16이 됩니다.'},
  shove:{name:'벽으로 몰아',effect:'8초간 2초마다 주변 적을 밀어냅니다. 밀려 벽이나 가구에 부딪히면 피해 12.'},
  crush:{name:'빠져나갈 틈을 주지 마',effect:'12초간 1초마다 주변 적을 밀어내고 충돌 피해 20을 줍니다.'},
  pursue:{name:'약한 놈부터',effect:'10초간 체력이 절반 이하인 적에게 모든 공격 피해가 50% 증가합니다.'},
  finishOff:{name:'놓치지 마',effect:'12초간 체력이 절반 이하인 적에게 두 배 피해를 줍니다.'},
  net:{name:'그 자리에 묶어',effect:'8초간 감속된 적이 맞으면 3초마다 한 번씩 추가 피해 8. 스네이크와 연계됩니다.'},
  tighten:{name:'포위망을 조여',effect:'12초간 감속된 적이 맞으면 1초마다 한 번씩 추가 피해 12.'},
  bait:{name:'미끼를 남겨',effect:'시엘이 서 있던 곳에 8초간 미끼를 놓습니다. 1초마다 주변 3m의 적을 중심으로 당깁니다.'},
  ambush:{name:'한곳에 모아',effect:'미끼가 12초간 4m의 적을 당기며 매번 피해 5를 줍니다.'},
  delay:{name:'셋을 세어',effect:'현재 위치에서 3초 뒤 반경 3m 폭발. 범위 안의 적 모두에게 피해 24.'},
  salvo:{name:'뒤따르는 놈까지',effect:'현재 위치에서 2초·4초·6초 뒤 반경 3m 폭발. 매회 피해 20.'},
  stride:{name:'걸음을 늦추지 마',effect:'10초간 2m 이동할 때마다 원형 충격으로 주변 2m에 피해 9.'},
  breakout:{name:'포위망을 뚫어',effect:'12초간 1m 이동마다 반경 3m에 피해 12와 밀치기. 멈추면 발동하지 않습니다.'},
  hold:{name:'여기서 버텨',effect:'10초간 제자리에 1초 머물 때마다 7m 안의 가까운 적 둘에게 피해 12.'},
  citadel:{name:'사선을 사수해',effect:'12초간 제자리에 0.75초 머물 때마다 8m 안의 적 넷에게 피해 16.'},
  retrieve:{name:'물자를 회수해',effect:'8초간 4m 안의 파편과 오더를 끌어옵니다. 하나 주울 때마다 사용인들의 기본 공격을 준비합니다.'},
  reserve:{name:'예비대를 투입해',effect:'10초간 6m 안의 파편과 오더를 끌어옵니다. 주우면 사용인 공격을 준비하고 물자 3개마다 호위 1칸을 회복합니다.'},
  relay:{name:'공격을 이어받아',effect:'8초간 사용인이 기본 기술을 쓸 때마다 그 자리에서 가까운 적 하나에 지원 사격 피해 9.'},
  chorus:{name:'일제히 사격해',effect:'12초간 사용인의 기본 기술마다 그 자리에서 가까운 적 셋에 각각 지원 사격 피해 12.'},
  snare:{name:'발을 묶어', effect:'6m 안의 적 넷을 5초간 45% 감속합니다. 메이린의 관통탄이 추가 피해를 줍니다.'},
  quarry:{name:'사냥감을 몰아', effect:'8m 안의 적을 6초간 감속하고 표식으로 받는 피해를 30% 높입니다.'},
  fireline:{name:'퇴로를 태워', effect:'최근 이동 경로 3m에 5초간 불길을 남깁니다. 피니안으로 적을 밀어 넣을 수 있습니다.'},
  furnace:{name:'불길을 넓혀', effect:'현재 불길을 4초 연장하고 시엘 주위 네 방향에 6초간 불길을 놓습니다.'},
  screen:{name:'대열을 지켜', effect:'5초간 접촉 한 번을 막고 모든 사용인의 기본 공격을 즉시 준비합니다.'},
  rally:{name:'반격을 개시해', effect:'5초간 접촉 한 번을 막고 모든 사용인에게 즉시 고유 명령을 내립니다. 1초 뒤 한 번 더 명령합니다.'}
};
function castTactic(g,key) {
  if(key==='delay'||key==='salvo'){
    const center=copyPoint(g.player);
    for(const delay of key==='delay'?[180]:[120,240,360]){
      effect(g,'fuse',center,center,{range:3,end:g.tick+delay});
      g.pending.push({due:g.tick+delay,run:()=>{
        effect(g,'shock',center,center,{range:3});
        for(const e of sortedTargets(g,center,3))damage(g,e,key==='delay'?24:20);
      }});
    }
    return;
  }
  const stance = {
    spark:['chain',480,1],cascade:['chain',720,2],shove:['ram',480,1],crush:['ram',720,2],
    pursue:['cull',600,1],finishOff:['cull',720,2],net:['bind',480,1],tighten:['bind',720,2],
    bait:['lure',480,1],ambush:['lure',720,2],
    stride:['march',600,1],breakout:['march',720,2],hold:['bastion',600,1],citadel:['bastion',720,2],
    retrieve:['supply',480,1],reserve:['supply',600,2],relay:['echo',480,1],chorus:['echo',720,2]
  }[key];
  if (stance) {
    const [type,duration,rank]=stance;
    g.stances[type]={until:g.tick+duration,rank,progress:0,origin:copyPoint(g.player)};
    g.lastSilverNotice={tick:g.tick,text:TACTICS[key].name+' · '+duration/60+'초'};
    return;
  }
  if (key === 'snare' || key === 'quarry') {
    const marked = key === 'quarry';
    for (const e of sortedTargets(g,g.player,marked?8:6).slice(0,marked?Infinity:4)) {
      e.slows.push({rate:.45,end:g.tick+(marked?360:300)});
      if (marked) e.markUntil = Math.max(e.markUntil||0,g.tick+360);
      effect(g,'snake',g.player,e);
    }
  } else if (key === 'fireline' || key === 'furnace') {
    const ring = key === 'furnace';
    if (ring) for (const fire of g.fires) fire.end += 240;
    for (let i=0;i<4;i++) {
      const p = ring ? point(g.player.x+Math.cos(i*Math.PI/2),g.player.y+Math.sin(i*Math.PI/2)) : trailAt(g,i);
      g.fires.push({...copyPoint(free(g.room,p,.1)?p:g.player),born:g.tick,end:g.tick+(ring?360:300)});
    }
  } else {
    g.shield = g.tick+300;
    effect(g,'guard',g.player,g.player,{range:1});
    if (key === 'screen') for (const u of g.units) u.ready=g.tick;
    else {
      const volley = () => { for (const u of g.units) g.invoke(u.key,true); };
      volley();
      g.pending.push({due:g.tick+60,run:volley});
    }
  }
}

const ENEMY = {chaser:[18, 1.15, .22], elite:[36, .9, .29], charger:[25, 1.15, .24], boss:[160, 1.05, .38]};
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const point = (x, y) => ({x, y});
const copyPoint = p => point(p.x, p.y);
const unit = (x, y) => {
  const n = Math.hypot(x, y) || 1;
  return point(x / n, y / n);
};
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const to = (a, b) => unit(b.x - a.x, b.y - a.y);
const dot = (a, b) => a.x * b.x + a.y * b.y;
function randomStream(seed, label) {
  let state = 2166136261;
  for (const ch of String(seed) + '/' + label) state = Math.imul(state ^ ch.charCodeAt(0), 16777619) >>> 0;
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let n = state;
    n = Math.imul(n ^ (n >>> 15), n | 1);
    n ^= n + Math.imul(n ^ (n >>> 7), n | 61);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1;i > 0;i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function free(room, p, r) {
  if (p.x < r || p.x > 20 - r || p.y < r || p.y > 12 - r)return false;
  return ROOMS[room].blocks.every(([x, y, w, h]) => Math.hypot(p.x - clamp(p.x, x, x + w), p.y - clamp(p.y, y, y + h)) >= r - 1e-8);
}
// Small steps preserve circular collisions during knockback as well as normal movement.
function travel(room, p, dx, dy, r) {
  const count = Math.max(1, Math.ceil(Math.hypot(dx, dy) / .1));
  let hit = false;
  for (let i = 0;i < count;i++) {
    if (free(room, point(p.x + dx / count, p.y), r))p.x += dx / count;else hit = true;
    if (free(room, point(p.x, p.y + dy / count), r))p.y += dy / count;else hit = true;
  }
  return hit;
}
function visible(room, a, b, r) {
  const count = Math.ceil(distance(a, b) / .18);
  for (let i = 1;i <= count;i++)if (!free(room, point(a.x + (b.x - a.x) * i / count, a.y + (b.y - a.y) * i / count), r))return false;
  return true;
}
const gridPoint = id => point((id % 40) * .5 + .25, Math.floor(id / 40) * .5 + .25);
const grids = new Map();
function navigate(room, a, b, r) {
  if (visible(room, a, b, r))return b;
  const key = room + '/' + r;
  if (!grids.has(key)) {
    const ok = Array.from({length:960}, (_, i) => free(room, gridPoint(i), r));
    const edges = ok.map((isOpen, i) => !isOpen?[]:[i - 40, i % 40 === 39?-1:i + 1, i + 40, i % 40 === 0?-1:i - 1].filter(j => ok[j] && visible(room, gridPoint(i), gridPoint(j), r)));
    grids.set(key, {ok, edges, fields:new Map()});
  }
  const g = grids.get(key);
  function cell(p) {
    const i = clamp(Math.floor(p.y * 2), 0, 23) * 40 + clamp(Math.floor(p.x * 2), 0, 39);
    if (g.ok[i])return i;
    let best = -1, d = Infinity;
    g.ok.forEach((v, j) => {
      if (v && distance(p, gridPoint(j)) < d) {
        best = j;
        d = distance(p, gridPoint(j));
      }
    });
    return best;
  }
  const start = cell(a), end = cell(b);
  if (!g.fields.has(end)) {
    const field = new Int16Array(960).fill(-1), q = [end];
    field[end] = 0;
    for (let i = 0;i < q.length;i++)for (const j of g.edges[q[i]])if (field[j] === -1) {
      field[j] = field[q[i]] + 1;
      q.push(j);
    }
    if (g.fields.size > 100)g.fields.clear();
    g.fields.set(end, field);
  }
  const d = g.fields.get(end);
  let id = start;
  for (let i = 0;i < 8 && id !== end;i++) {
    const next = g.edges[id].find(j => d[j] === d[id] - 1 && d[j] >= 0);
    if (next === undefined || !visible(room, a, gridPoint(next), r))break;
    id = next;
  }
  return gridPoint(id);
}
function trailAt(g, back) {
  const t = g.trail;
  let last = t[t.length - 1];
  for (let i = t.length - 2;i >= 0;i--) {
    const p = t[i], d = distance(last, p);
    if (d >= back && d)return point(last.x + (p.x - last.x) * back / d, last.y + (p.y - last.y) * back / d);
    back -= d;
    last = p;
  }
  return copyPoint(last);
}
function station(g, id) {
  const [forward, side] = PIECES[id].formation, p = g.player, f = g.facing;
  const base = forward < 0?trailAt(g, -forward):point(p.x + forward * f.x, p.y + forward * f.y);
  const dest = point(base.x - side * f.y, base.y + side * f.x);
  if (free(g.room, dest, .17))return dest;
  let best = p, d = Infinity;
  for (const a of g.trail)if (free(g.room, a, .17) && distance(a, dest) < d) {
    best = a;
    d = distance(a, dest);
  }
  return best;
}
function sortedTargets(g, p, range, pred = () => true) {
  return g.enemies.filter(e => e.hp > 0 && distance(e, p) <= range + 1e-8 && pred(e)).sort((a, b) => distance(a, p) - distance(b, p) || a.id - b.id);
}
function sector(g, p, range, degrees) {
  return sortedTargets(g, p, range, e => distance(e, p) < 1e-8 || dot(to(p, e), g.facing) >= Math.cos(degrees * Math.PI / 360) - 1e-8);
}
function effect(g, type, a, b, attr = {}) {
  g.effects.push({type, a:copyPoint(a), b:copyPoint(b), start:g.tick, end:g.tick + 22, ...attr});
}
function slowAt(g, e) {
  return Math.max(0, ...e.slows.filter(s => s.end > g.tick).map(s => s.rate));
}
function damage(g, e, amount, quiet = false) {
  if (e.hp <= 0)return;
  const cull=g.stance('cull'), bind=g.stance('bind');
  if(cull && e.hp<=e.max/2)amount*=1+.5*cull.rank;
  if(bind && slowAt(g,e)>0 && !(e.bindReady>g.tick)){
    amount+=bind.rank===2?12:8;
    e.bindReady=g.tick+(bind.rank===2?60:180);
  }
  const value = amount * (e.markUntil > g.tick?1.3:1) * (e.kind === 'boss' && e.mode === 'rest'?1.5:1);
  e.hp -= value;
  e.flash = g.tick + 6;
  if (!quiet)effect(g, 'number', e, e, {value, end:g.tick + 29});
}
function pushAway(g, e, p, amount) {
  const dir = distance(e, p) < .0001?g.facing:to(p, e);
  const hit=travel(g.room,e,dir.x*amount,dir.y*amount,e.radius);
  const ram=g.stance('ram');
  if(hit && ram)damage(g,e,ram.rank===2?20:12);
}
function meyrin(g, u, command, probe = false) {
  const list = sortedTargets(g, u, 6), rear = list.find(e => dot(to(u, e), g.facing) < 0), target = rear || list[0];
  if (!target)return false;
  if (probe)return true;
  const direction = distance(target, u) < 1e-8?g.facing:to(u, target), width = (u.level === 2?.65:.4) + g.orderRank*.12;
  function shoot(dir, followUp = false) {
    u.bracedUntil = g.tick + 9;
    let hits = 0;
    for (const e of g.enemies) {
      if (e.hp <= 0)continue;
      const dx = e.x - u.x, dy = e.y - u.y, along = dx * dir.x + dy * dir.y;
      if (along >= 0 && along <= 6 && Math.abs(dx * dir.y - dy * dir.x) <= width / 2 + 1e-8) {
        damage(g, e, 14 + 4*g.orderRank + (slowAt(g, e) > 0?5:0));
        if(slowAt(g,e)>0)g.links.slowHits++;
        hits++;
      }
    }
    g.log.beams.push({room:g.room, tick:g.tick, hits, command});
    effect(g, 'beam', u, point(u.x + dir.x * 6, u.y + dir.y * 6), {width, hits, followUp});
  }
  shoot(direction);
  if (!command && comboActive(g,'meyrin')) {
    const angle = Math.atan2(direction.y,direction.x);
    for (const offset of [-.24,.24])shoot(point(Math.cos(angle+offset),Math.sin(angle+offset)),true);
  }
  if (command && u.level === 2)g.pending.push({due:g.tick + 15, run:() => shoot(direction, true)});
  return true;
}
function finny(g, u, command, probe = false) {
  const origin = command?g.player:u, range = (u.level === 2?1.7:1.3) + .17*g.orderRank, targets = sortedTargets(g, origin, range);
  if (!targets.length)return false;
  if (probe)return true;
  targets.forEach(e => {
    damage(g, e, 9 + 4*g.orderRank);
    pushAway(g, e, origin, command && u.level === 2?1.5:1);
  });
  if (!command && comboActive(g,'finny'))g.shield = Math.max(g.shield,g.tick+90);
  effect(g, 'shock', origin, origin, {range});
  return true;
}
function bard(g, u, command, probe = false) {
  if (probe)return true;
  for (const p of command?[trailAt(g, 0), trailAt(g, 1), trailAt(g, 2)]:comboActive(g,'bard')?[u,trailAt(g,1),trailAt(g,2)]:[u]) {
    g.fires.push({...copyPoint(p), owner:"bard", born:g.tick, end:g.tick + (u.level === 2?180:120)});
  }
  return true;
}
function snake(g, u, command, probe = false) {
  const targets = sortedTargets(g, u, (command?4:3) + .25*g.orderRank, e => command || dot(to(u, e), g.facing) <= 0).slice(0, (command || u.level === 2?3:2) + Math.ceil(g.orderRank/2));
  if (!targets.length)return false;
  if (probe)return true;
  for (const e of targets) {
    e.slows.push({rate:(command?.5:.4) + .04*g.orderRank, end:g.tick + (command && u.level === 2?180:120)});
    if (!command && comboActive(g,'snake'))for (const other of sortedTargets(g,e,1.5,o=>o!==e)) {
      other.slows.push({rate:.5,end:g.tick+120});
      effect(g,'snake',e,other);
    }
    effect(g, 'snake', u, e);
  }
  return true;
}
function lizzy(g, u, command, probe = false) {
  const radius = (command?(u.level === 2?2.3:2):1.3) + .16*g.orderRank, degrees = command || u.level === 2?140:100;
  const targets = sector(g, u, radius, degrees);
  if (!targets.length)return false;
  if (probe)return true;
  if(!command && comboActive(g,'lizzy')) {
    const back = sortedTargets(g,u,2,e=>dot(to(u,e),g.facing)<0);
    for(const e of back)damage(g,e,12);
    effect(g,'slash',u,point(-g.facing.x,-g.facing.y),{range:2,degrees:180});
  }
  targets.forEach(e => damage(g, e, (command?(u.level === 2?20:16):12) + 4*g.orderRank));
  effect(g, 'slash', u, g.facing, {range:radius, degrees});
  return true;
}
const TRAINING = {
  volley: {name:'협동 사격', text:['사용인이 기본 기술을 쓸 때 5m 안의 적 하나에 추가 피해 8.', '추가 사격이 두 적에게 각각 피해 12.']},
  stride: {name:'돌파 대형', text:['4m 이동할 때마다 시엘 주위 2m에 피해 8.', '3m마다 반경 3m에 피해 12.']},
  ward: {name:'교대 호위', text:['격파 6회마다 3초간 접촉 1회 방어.', '격파 4회마다 5초간 접촉 1회 방어.']},
  reach: {name:'보급 회수', text:['경험치 회수 반경 1.2m → 2.4m.', '회수 반경 3.6m. 경험치 결정 하나당 경험치 +1.']}
};
const CUES = {walk:'4m 이동', crystal:'경험치 결정 2개 회수', ally:'사용인 기본 기술 2회', contact:'적과 접촉'};
const TRICKS = {fire:'발동 위치에 3초 불길', pull:'3m 안의 적을 1m 끌어오기', frost:'3m 안의 적을 2초간 50% 감속', shot:'6m 안의 적 셋에 은식기 피해 8'};
const CUE_COST = {walk:4, crystal:2, ally:2, contact:1};
function playTrick(g,event,amount,origin) {
  if (!g.custom || g.custom.cue !== event)return;
  const c=g.custom;
  c.charge += amount;
  if(c.charge+1e-8 < CUE_COST[event])return;
  c.charge -= CUE_COST[event];
  c.count++;
  if(c.trick==='fire'){
    g.fires.push({...copyPoint(origin),born:g.tick,end:g.tick+180});
  }else if(c.trick==='shot'){
    g.supportShot(origin,3,6,8);
  }else{
    effect(g,'shock',origin,origin,{range:3});
    for(const enemy of sortedTargets(g,origin,3)){
      if(c.trick==='frost')enemy.slows.push({rate:.5,end:g.tick+120});
      else {
        const dir=to(enemy,origin), step=Math.min(1,distance(enemy,origin));
        const before=copyPoint(enemy);
        travel(g.room,enemy,dir.x*step,dir.y*step,enemy.radius);
        if(distance(before,enemy)>.01){
          if(!enemy.everPulled)g.links.pulled++;
          enemy.everPulled=true;
          enemy.pullUntil=g.tick+180;
        }
      }
    }
  }
}
const COMBOS = {
  meyrin:{perk:'volley',name:'교차 사격',effect:'기본 사격 뒤 좌우로 갈라지는 관통탄 두 발을 더 쏩니다.'},
  finny:{perk:'ward',name:'철벽 호위',effect:'기본 밀치기에 성공하면 1.5초간 접촉을 한 번 막습니다.'},
  bard:{perk:'stride',name:'화염 회랑',effect:'기본 공격 때 지나온 길 1m와 2m 지점에도 불길을 남깁니다.'},
  snake:{perk:'reach',name:'독사 포위',effect:'감속을 건 적 주위 1.5m의 다른 적도 2초간 50% 느려집니다.'},
  lizzy:{perk:'stride',name:'반전 검무',effect:'기본 전방 베기에 이어 후방 2m 안의 적도 피해 12로 벱니다.'}
};
function comboActive(g,key) {
  return !!(g.roster[key] && g.training[COMBOS[key].perk]);
}
const ROOM_EXIT_TICKS = [25 * HZ, 150 * HZ, Infinity];
const HAND_TICKS = [[10 * HZ], [12 * HZ, 30 * HZ, 58 * HZ, 85 * HZ, 115 * HZ, 140 * HZ]];
function wavePlan(room) {
  const events = [];
  function band(start, end, interval, count, side) {
    for (let tick = start * HZ, i = 0;tick < end * HZ;tick += Math.round(interval * HZ), i++)
    events.push({at:tick, kind:'chaser', side:side === 'alt'?(i % 2?'W':'E'):side, count});
  }
  if (room === 0) {
    band(0, 8, 2, 1, 'W');
    band(8, 18, 1.5, 1, 'alt');
    band(18, ROOM_EXIT_TICKS[0] / HZ, 1, 1, 'E');
    events.push({at:14 * HZ, kind:'elite', side:'W', count:1});
  }
  if (room === 1) {
    band(0, 20, 1.5, 1, 'W');
    band(20, 45, 1, 1, 'alt');
    band(45, 60, 1.2, 2, 'E');
    band(60,90,1.4,2,'alt');
    band(90,120,1,2,'W');
    band(120,150,.9,2,'alt');
    for(const t of [68,98,130])events.push({at:t*HZ,kind:'elite',side:'E',count:1});
    for (const t of [25,40,52,76,83,104,112,132,143])events.push({at:t * HZ, kind:'charger', side:'N', count:1});
  }
  return events.sort((a, b) => a.at - b.at || Number(b.kind !== 'chaser') - Number(a.kind !== 'chaser'));
}
class Game{
  constructor(seed = '1889', commands = true) {
    this.seed = String(seed);
    this.commands = commands;
    this.hp = 6;
    this.schoolPicks = [];
    this.training = {};
    this.trainingLevel = 0;
    this.redraws = 1;
    this.redrawLevel = -1;
    this.xp = 0;
    this.links = {pulled:0,burned:0,slowHits:0};
    this.revisions = [];
    this.wardKills = 0;
    this.strideDistance = 0;
    this.roster = {};
    this.deck = [];
    this.cardId = 0;
    this.choice = 0;
    this.resultCount = 0;
    this.kills = 0;
    initSilver(this);
    this.rng = {wave:randomStream(seed, 'wave'), reward:randomStream(seed, 'reward'), deck:randomStream(seed, 'deck')};
    this.log = {rooms:[], picks:[], hands:[], commands:[], beams:[], spawns:[]};
    for (const key of ['guard', 'guard', 'open', 'open'])this.addCard(key);
    this.enter(0);
  }
  addCard(key) {
    this.deck.push({id:++this.cardId, key, level:1});
  }
  enter(room) {
    this.room = room;
    this.tick = 0;
    this.phase = 'fight';
    this.door = false;
    this.reinforced = false;
    this.searches = room === 1 ? [
      {x:12,y:2,field:'trick',name:'북쪽 서가'},
      {x:7,y:6,field:'cue',name:'중앙 서랍'}
    ] : [];
    this.bell = room === 1 ? {x:10,y:2,state:'idle'} : null;
    this.ended = false;
    this.player = point(2, 6);
    this.facing = point(1, 0);
    this.walk = 0;
    this.stances = {};
    this.cool = 0;
    this.immune = 0;
    this.shield = 0;
    this.trail = Array.from({length:18}, (_, i) => point(1.15 + i * .05, 6));
    this.trail.push(copyPoint(this.player));
    this.enemies = [];
    this.warnings = [];
    this.items = [];
    this.crystals = [];
    prepareSilverRoom(this);
    this.fires = [];
    this.effects = [];
    this.pending = [];
    this.enemyId = 0;
    this.units = Object.entries(this.roster).map(([key, level]) => ({key, level, ...station(this, key), ready:0}));
    this.draw = shuffle(this.deck.map(c => ({...c})), this.rng.deck);
    if (this.schoolPicks.length) {
      const school=this.schoolPicks.at(-1);
      const newest=SCHOOLS[school].cards[this.schoolPicks.filter(k=>k===school).length-1];
      const index=this.draw.findIndex(c=>c.key===newest);
      if(index>=0)this.draw.push(this.draw.splice(index,1)[0]);
    }
    this.discard = [];
    this.hand = [];
    this.candidates = [];
    this.waves = wavePlan(room);
    this.waveIndex = 0;
    this.exitTick = ROOM_EXIT_TICKS[room];
    this.nextHand = room === 2 ? 12 * HZ : HAND_TICKS[room][0];
    this.stats = {room, hits:0, elapsed:0};
    this.log.rooms.push(this.stats);
    if (room === 2) {
      this.enemy('boss', 16, 6);
      if (this.commands)this.deal();
    }
  }
  enemy(kind, x, y) {
    const [hp, speed, radius] = ENEMY[kind], e = {id:++this.enemyId, kind, x, y, hp, max:hp, speed, radius, mode:'chase', until:kind === 'boss'?this.tick + 180:0, dx:1, dy:0, slows:[], fireReady:0, flash:0};
    this.enemies.push(e);
    return e;
  }
  deal() {
    if (this.phase !== 'fight')return;
    for (let i = 0;i < 2;i++) {
      if (!this.draw.length) {
        this.draw = shuffle(this.discard, this.rng.deck);
        this.discard = [];
      }
      if (this.draw.length)this.hand.push(this.draw.pop());
    }
    this.phase = 'hand';
    this.choice++;
    this.log.hands.push({room:this.room, tick:this.tick, cards:this.hand.map(c => c.key), ids:this.hand.map(c => c.id)});
  }
  invoke(key, command, probe = false, context = {extra:false}) {
    // Expansion skills may ask for an extra cast using this guarded dispatcher.
    const u = this.units.find(u => u.key === key);
    if (!u)return false;
    const triggerExtra = other => context.extra?false:this.invoke(other, false, false, {extra:true});
    return PIECES[key].skill(this, u, command, probe, triggerExtra);
  }
  can(card) {
    if (TACTICS[card.key]) {
      if (card.key === 'snare' || card.key === 'quarry')return sortedTargets(this,this.player,card.key==='snare'?6:8).length>0;
      return true;
    }
    if (card.key === 'guard')return true;
    if (card.key === 'open')return sector(this, this.player, 2, 90).length > 0;
    return this.invoke(card.key, true, true);
  }
  order(id, token = this.choice) {
    if (this.phase !== 'hand' || token !== this.choice)return false;
    const card = this.hand.find(c => c.id === id);
    if (id !== null && (!card || !this.can(card)))return false;
    if (card) {
      if (TACTICS[card.key])castTactic(this,card.key);
      else if (card.key === 'guard') {
        this.shield = this.tick + 120;
        effect(this, 'guard', this.player, this.player, {range:1});
      }
      else if (card.key === 'open') {
        for (const e of sector(this, this.player, 2, 90)) {
          damage(this, e, 5);
          pushAway(this, e, this.player, .8);
        }
        effect(this, 'open', this.player, this.facing, {range:2, degrees:90});
      }
      else this.invoke(card.key, true);
      this.log.commands.push({room:this.room, tick:this.tick, key:card.key});
    }
    this.discard.push(...this.hand);
    this.hand = [];
    this.phase = 'fight';
    this.resolveDeaths();
    return true;
  }
  reward() {
    if (this.phase !== 'fight')return;
    const rng = this.rng.reward;
    const previous = this.schoolPicks[0];
    const pool = Object.keys(SCHOOLS).filter(k=>k!==previous);
    const options = shuffle(pool,randomStream(this.seed,'school-'+this.room));
    this.schoolOffers = previous?[previous,...options.slice(0,2)]:options.slice(0,3);
    if (this.room === 0)
    this.candidates = shuffle(['finny', 'meyrin', 'bard'], rng);
    else{
      const owned = Object.keys(this.roster)[0], others = trialKeys().filter(k => !this.roster[k]);
      const partner = shuffle(PIECES[owned].link.filter(k => others.includes(k)), rng)[0] || shuffle(others, rng)[0];
      const extra = shuffle(others.filter(k => k !== partner), rng)[0];
      this.candidates = shuffle([owned, partner, extra], rng);
    }
    this.phase = 'reward';
    this.choice++;
  }
  choose(key, token = this.choice, school = null) {
    if (this.phase !== 'reward' || token !== this.choice || !this.candidates.includes(key))return false;
    if (school !== null) {
      if (!this.commands || !this.schoolOffers.includes(school))return false;
      const tier=this.schoolPicks.includes(school)?1:0;
      const slot=this.deck.find(c=>c.key===(this.schoolPicks.length?'open':'guard'));
      if (!slot)return false;
      slot.key=SCHOOLS[school].cards[tier];
      this.schoolPicks.push(school);
    }
    if (this.roster[key]) {
      this.roster[key] = 2;
      this.deck.find(c => c.key === key).level = 2;
    }
    else{
      this.roster[key] = 1;
      this.addCard(key);
    }
    this.log.picks.push({room:this.room, key, level:this.roster[key]});
    if(this.room===1){
      this.reinforced=true;
      const previousUnit=this.units.find(u=>u.key===key);
      if(previousUnit)previousUnit.level=this.roster[key];
      else this.units.push({key,level:1,...station(this,key),ready:this.tick});
      // Reconcile the live piles by card ID without reshuffling the room.
      const live=[...this.draw,...this.discard];
      for(const card of this.deck){
        const old=live.find(c=>c.id===card.id);
        if(old)Object.assign(old,card);
        else this.draw.push({...card});
      }
      this.phase='fight';
    }else this.enter(this.room + 1);
    return true;
  }
  finish(outcome) {
    if (this.ended)return;
    this.ended = true;
    this.phase = outcome;
    this.resultCount++;
  }
  get xpNeeded() { return 3 + this.trainingLevel * 3; }
  trainingOffers() {
    const keys = Object.keys(TRAINING).filter(k => (this.training[k] || 0) < 2);
    const pool = shuffle(keys, randomStream(this.seed, 'training-' + this.trainingLevel));
    if (this.redrawLevel === this.trainingLevel)pool.unshift(pool.pop());
    return pool.slice(0,3);
  }
  redrawTraining() {
    if (this.phase !== 'fight' || this.xp < this.xpNeeded || !this.redraws)return false;
    if (Object.keys(TRAINING).filter(k => (this.training[k] || 0) < 2).length <= 3)return false;
    this.redrawLevel = this.trainingLevel;
    this.redraws--;
    return true;
  }
  train(key) {
    if (this.phase !== 'fight' || this.xp < this.xpNeeded || !this.trainingOffers().includes(key))return false;
    this.xp -= this.xpNeeded;
    this.trainingLevel++;
    this.training[key] = (this.training[key] || 0) + 1;
    return true;
  }
  collectExperience() {
    const reach = this.training.reach || 0;
    this.crystals = this.crystals.filter(c => {
      if (distance(c,this.player) > 1.2 * (1 + reach) || !visible(this.room,c,this.player,.08))return true;
      const dir = to(c,this.player);
      const step = Math.min(distance(c,this.player), 8 * DT);
      c.x += dir.x * step;
      c.y += dir.y * step;
      if (distance(c,this.player) > .35)return true;
      playTrick(this,'crystal',1,c);
      this.xp += c.value + Number(reach === 2);
      return false;
    });
  }
  resolveDeaths() {
    const fallen=this.enemies.filter(e=>e.hp<=0);
    const chain=this.stance('chain');
    for(const e of fallen){
      if(chain){
        const range=chain.rank+1;
        effect(this,'shock',e,e,{range});
        for(const other of sortedTargets(this,e,range)){
          damage(this,other,chain.rank===2?16:9);
          if(other.hp<=0)fallen.push(other);
        }
      }
      if (e.bellGuard) {
        this.exitTick = Math.min(this.exitTick,this.tick);
        this.bell.state = 'cleared';
      }
      this.kills++;
      if (e.kind !== 'boss' && this.trainingLevel < 8)
        this.crystals.push({...copyPoint(e), value:e.kind === 'chaser' ? 1 : 3});
      const ward = this.training.ward;
      if (ward && ++this.wardKills >= (ward === 2 ? 4 : 6)) {
        this.wardKills = 0;
        this.shield = Math.max(this.shield,this.tick + (ward === 2 ? 5 : 3) * HZ);
      }
      effect(this, 'death', e, e);
      if (e.kind === 'elite')this.items.push(copyPoint(e));
      if (e.kind !== 'boss' && (e.kind !== 'chaser' || this.kills % 3 === 0))placeSilver(this,e);
      if (e.kind === 'boss')this.finish('win');
    }
    this.enemies = this.enemies.filter(e => e.hp > 0);
  }
  discovery(site) {
    if (!this.custom || this.phase !== 'fight' || !this.reinforced || this.door || !this.searches.includes(site))return null;
    const round = this.tick >= 90*HZ ? 2 : 1;
    if(this.searchRound === round)return null;
    const pool=Object.keys(site.field==='cue'?CUES:TRICKS).filter(k=>k!==this.custom[site.field]);
    const key=shuffle(pool,randomStream(this.seed,site.field+'-search-'+round))[0];
    return {key,round};
  }
  revise(site) {
    const offer=this.discovery(site);
    if(!offer || distance(this.player,site)>1.1)return false;
    this.revisions.push({field:site.field,from:this.custom[site.field],to:offer.key,count:this.custom.count});
    this.custom[site.field]=offer.key;
    this.custom.charge=0;
    this.searchRound=offer.round;
    return true;
  }
  canRing() {
    return this.tick >= 105*HZ && this.phase === 'fight' && this.bell?.state === 'idle' && !this.door
      && this.tick < this.exitTick - 36 && distance(this.player,this.bell) < 1.4
      && this.enemies.length + this.warnings.length < 22;
  }
  ringBell() {
    if (!this.canRing())return false;
    this.bell.state = 'called';
    this.warnings.push({x:15,y:2,kind:'elite',bellGuard:true,end:this.tick+36});
    return true;
  }
  schedule(group) {
    const cap = this.room === 2?9:22;
    for (let i = 0;i < group.count;i++) {
      // Consume a fixed sample budget even for capped or unsafe entries.
      const draws = Array.from({length:24}, () => this.rng.wave());
      if (this.enemies.length + this.warnings.length >= cap)continue;
      let location;
      for (const v of draws) {
        const p = group.side === 'N'?point(.5 + v * 19, 1.42):point(group.side === 'E'?19.6:.4, .45 + v * 11.1);
        if (free(this.room, p, ENEMY[group.kind][2]) && distance(this.player, p) >= 2) {
          location = p;
          break;
        }
      }
      if (location)this.warnings.push({...location, kind:group.kind, end:this.tick + 36});
    }
  }
  advanceWaves() {
    if (this.room === 2) {
      if (this.tick % 480 === 0)this.schedule({kind:'chaser', side:(this.tick / 480) % 2?'E':'W', count:2});
    }else if (this.tick < this.exitTick) {
      while (this.waveIndex < this.waves.length && this.waves[this.waveIndex].at <= this.tick)this.schedule(this.waves[this.waveIndex++]);
    }
    this.warnings = this.warnings.filter(w => {
      if (this.room !== 2 && this.tick >= this.exitTick)return false;
      if (this.tick < w.end)return true;
      if (distance(this.player, w) >= 2) {
        const enemy = this.enemy(w.kind, w.x, w.y);
        if (w.bellGuard)enemy.bellGuard = true;
        this.log.spawns.push([this.tick, w.kind, w.x, w.y]);
      }
      return false;
    });
  }
  moveEnemy(e) {
    e.slows = e.slows.filter(s => s.end > this.tick);
    const boss = e.kind === 'boss', charging = boss || e.kind === 'charger';
    if (charging) {
      if (e.mode === 'rest' && this.tick >= e.until) {
        e.mode = 'chase';
        e.until = this.tick + 180;
      }
      if (e.mode === 'chase' && this.tick >= e.until && (boss || distance(e, this.player) <= 4)) {
        const dir = to(e, this.player);
        e.dx = dir.x;
        e.dy = dir.y;
        e.mode = 'warn';
        e.until = this.tick + (boss?54:48);
      }else if (e.mode === 'warn' && this.tick >= e.until) {
        e.mode = 'dash';
        e.until = this.tick + (boss?39:27);
      }
      if (e.mode === 'dash') {
        const hit = this.tick < e.until && travel(this.room, e, e.dx * 5 * DT, e.dy * 5 * DT, e.radius);
        if (hit || this.tick >= e.until) {
          e.mode = 'rest';
          e.until = this.tick + (boss?90:66);
        }
        return;
      }
      if (e.mode !== 'chase')return;
    }
    const dest = navigate(this.room, e, this.player, e.radius), dir = to(e, dest), d = Math.min(distance(e, dest), e.speed * (1 - slowAt(this, e)) * DT);
    travel(this.room, e, dir.x * d, dir.y * d, e.radius);
  }
  stance(type) {
    const state=this.stances[type];
    return state && state.until>this.tick?state:null;
  }
  supportShot(origin,count,range,power) {
    for(const e of sortedTargets(this,origin,range).slice(0,count)) {
      damage(this,e,power);
      effect(this,'silver',origin,e);
    }
  }
  moveParty(input) {
    const before=this.walk;
    const n = Math.hypot(input.x, input.y), p = this.player;
    if (n > .001) {
      const prev = copyPoint(p), dir = unit(input.x, input.y);
      this.facing = dir;
      travel(this.room, p, dir.x * 3.2 * DT * Math.min(n, 1), dir.y * 3.2 * DT * Math.min(n, 1), .22);
      this.walk += distance(prev, p);
      if (distance(p, this.trail[this.trail.length - 1]) > .018) {
        this.trail.push(copyPoint(p));
        if (this.trail.length > 400)this.trail.shift();
      }
    }
    const moved=this.walk-before, march=this.stance('march'), bastion=this.stance('bastion');
    playTrick(this,'walk',moved,p);
    const stride = this.training.stride;
    if (stride) {
      this.strideDistance += moved;
      const interval = stride === 2 ? 3 : 4;
      if (this.strideDistance >= interval) {
        this.strideDistance -= interval;
        const range = stride === 2 ? 3 : 2;
        effect(this,'shock',p,p,{range});
        for (const e of sortedTargets(this,p,range))damage(this,e,stride === 2 ? 12 : 8);
      }
    }
    if(march) {
      march.progress+=moved;
      const interval=march.rank===2?1:2;
      if(march.progress>=interval) {
        march.progress-=interval;
        const range=march.rank===2?3:2;
        effect(this,'shock',p,p,{range});
        for(const e of sortedTargets(this,p,range)) {
          damage(this,e,march.rank===2?12:9);
          if(march.rank===2)pushAway(this,e,p,.5);
        }
      }
    }
    if(bastion) {
      bastion.progress=moved>.001?0:bastion.progress+1;
      if(bastion.progress>=(bastion.rank===2?45:60)) {
        bastion.progress=0;
        this.supportShot(p,bastion.rank*2,6+bastion.rank,8+4*bastion.rank);
      }
    }
    for (const u of this.units) {
      if (u.bracedUntil > this.tick)continue;
      const dest = navigate(this.room, u, station(this, u.key), .17), dir = to(u, dest), d = Math.min(4.5 * DT, distance(u, dest));
      travel(this.room, u, dir.x * d, dir.y * d, .17);
    }
  }
  allied() {
    const ram=this.stance('ram'), lure=this.stance('lure');
    if(ram && ram.progress++%(ram.rank===2?60:120)===0){
      effect(this,'shock',this.player,this.player,{range:2.5});
      for(const e of sortedTargets(this,this.player,2.5))pushAway(this,e,this.player,1.4);
    }
    if(lure && lure.progress++%60===0){
      const range=2+lure.rank;
      effect(this,'shock',lure.origin,lure.origin,{range});
      for(const e of sortedTargets(this,lure.origin,range)){
        const d=distance(e,lure.origin),dir=to(e,lure.origin),step=Math.min(d,1.2);
        travel(this.room,e,dir.x*step,dir.y*step,e.radius);
        if(lure.rank===2)damage(this,e,5);
      }
    }
    if (this.tick >= this.cool) {
      const target = sortedTargets(this, this.player, 5)[0];
      if (target) {
        damage(this, target, 7);
        effect(this, 'silver', this.player, target);
        this.cool = this.tick + 48;
      }
    }
    for (const u of this.units)if (this.tick >= u.ready && this.invoke(u.key, false)){
      playTrick(this,'ally',1,u);
      const volley = this.training.volley;
      if (volley)this.supportShot(u,volley,5,volley === 2 ? 12 : 8);
      const echo=this.stance('echo');
      if(echo)this.supportShot(u,echo.rank===2?3:1,6,echo.rank===2?12:9);
      u.ready = this.tick + Math.round(PIECES[u.key].time/(1 + .15*this.orderRank));
    }
    const due = this.pending.filter(t => t.due <= this.tick);
    this.pending = this.pending.filter(t => t.due > this.tick);
    due.forEach(t => t.run());
    this.fires = this.fires.filter(f => f.end >= this.tick);
    for (const e of this.enemies) {
      if (e.hp > 0 && this.tick >= e.fireReady && this.fires.some(f => this.tick > f.born && (this.tick - f.born) % 30 === 0 && distance(e, f) <= .8 + .14*this.orderRank)) {
        if(e.pullUntil>=this.tick && !e.burnCounted && this.fires.some(f=>f.owner==='bard' && this.tick>f.born && (this.tick-f.born)%30===0 && distance(e,f)<=.8+.14*this.orderRank)){
          e.burnCounted=true;this.links.burned++;
        }
        damage(this, e, 3 + this.orderRank);
        e.fireReady = this.tick + 30;
      }
    }
  }
  step(input = point(0, 0)) {
    if (this.phase !== 'fight')return;
    this.tick++;
    this.stats.elapsed = this.tick;
    this.advanceWaves();
    this.moveParty(input);
    for (const e of this.enemies)this.moveEnemy(e);
    this.effects = this.effects.filter(f => f.end > this.tick);
    this.allied();
    advanceSilver(this);
    this.resolveDeaths();
    if (this.ended)return;
    if (this.tick >= this.immune && this.enemies.some(e => distance(e, this.player) <= .22 + e.radius)) {
      playTrick(this,'contact',1,this.player);
      this.immune = this.tick + 75;
      if (this.shield > this.tick)
      this.shield = 0;else{
        this.hp--;
        this.stats.hits++;
        effect(this, 'hurt', this.player, this.player);
      }
      if (this.hp === 0) {
        this.finish('loss');
        return;
      }
    }
    collectSilver(this);
    this.collectExperience();
    this.items = this.items.filter(p => {
      if (distance(this.player, p) > .6)return true;
      this.hp = Math.min(6, this.hp + 1);
      effect(this, 'heal', p, p);
      return false;
    });
    if(this.room===1 && !this.reinforced && this.tick>=22*HZ){
      this.reward();
      return;
    }
    if (this.room !== 2 && this.tick >= this.exitTick) {
      this.door = true;
      if (distance(this.player, point(19, 6)) <= .55) {
        if(this.room===1)this.enter(2);else this.reward();
        return;
      }
    }
    if (this.commands && this.tick === this.nextHand) {
      this.nextHand = this.room === 2 ? this.tick + 1500 : (HAND_TICKS[this.room].find(t => t > this.tick) ?? Infinity);
      this.deal();
    }
  }
}
function screenInput(x, y, iso) {
  if (!iso)return point(x, y);
  const n = Math.min(1, Math.hypot(x, y)), dir = unit(x + 2 * y, 2 * y - x);
  return point(dir.x * n, dir.y * n);
}
