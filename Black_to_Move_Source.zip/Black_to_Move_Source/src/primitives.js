// Pixel sprite and drawing helpers retained from the earlier prototype.
function ellipse(x, y, rx, ry, color, fill = false, weight = 1) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.lineWidth = weight;
  if (fill) {
    ctx.fillStyle = color;
    ctx.fill()
  }else{
    ctx.strokeStyle = color;
    ctx.stroke()
  }
}
function stroke(x, y, bx, by, color, width = 1) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(bx, by);
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.stroke()
}
function sprite(im, x, y, h, facing = 1) {
  if (!im)return;
  const w = Math.round(im.width * h / im.height);
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));
  ctx.scale(facing, 1);
  ctx.drawImage(im, -Math.floor(w / 2), -h, w, h);
  ctx.restore()
}
