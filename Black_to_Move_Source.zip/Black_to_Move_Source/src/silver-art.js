// Cache at drawing resolution: even hundreds of missiles use a single textured quad each.
const silverAtlas=new Map();
const steelTones={
  fork:['#e4b78f','#fdf1ce','#b47c46'],
  knife:['#94d7ec','#e5feff','#428199'],
  spoon:['#dea5ed','#fff0ff','#a25fa9'],
  rain:['#c4cee9','#ffffff','#8293ca']
};
function utensilTexture(kind) {
  if(silverAtlas.has(kind))return silverAtlas.get(kind);
  const sprite=document.createElement('canvas');sprite.width=186;sprite.height=34;
  const c=sprite.getContext('2d'),[a,b,edge]=steelTones[kind];
  c.translate(144,17);
  function polygon(points,fill,outline) {
    c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();
    c.fillStyle=fill;c.fill();
    if(outline){c.lineWidth=1.5;c.strokeStyle=outline;c.stroke();}
  }
  const trail=c.createLinearGradient(-142,0,13,0);
  trail.addColorStop(0,a+'00');trail.addColorStop(.55,a+'19');trail.addColorStop(.87,a+'88');trail.addColorStop(1,b+'e6');
  polygon([[-142,0],[-16,-4],[15,0],[-15,4]],trail);
  const core=c.createLinearGradient(-112,0,14,0);
  core.addColorStop(0,b+'00');core.addColorStop(1,b);polygon([[-112,0],[10,-1.2],[16,0],[10,1.2]],core);
  const steel=c.createLinearGradient(0,-8,0,7);steel.addColorStop(0,a);steel.addColorStop(.4,'#fffef4');steel.addColorStop(.53,b);steel.addColorStop(.63,edge);steel.addColorStop(1,a);
  polygon([[-13,-2],[9,-1.6],[9,1.6],[-13,2],[-17,0]],steel,'#473d4a');
  if(kind==='fork'){
    polygon([[7,-2],[12,-6],[30,-6],[23,-3.6],[14,-3.2],[14,-1.5],[30,-1.3],[32,0],[14,1],[14,3.2],[29,3.7],[31,5.3],[13,5.8],[7,2]],steel,'#685143');
  }else if(kind==='spoon'){
    c.beginPath();c.ellipse(18,0,11,6,0,0,Math.PI*2);c.fillStyle=steel;c.fill();c.strokeStyle=edge;c.stroke();
    c.beginPath();c.ellipse(19,-1,6,3,0,Math.PI,Math.PI*1.85);c.strokeStyle=b;c.stroke();
  }else polygon([[6,-2.3],[30,-4.8],[36,-5],[26,1.8],[15,4.8],[7,3]],steel,'#4c5265');
  silverAtlas.set(kind,sprite);
  return sprite;
}
function drawSilverShots(g) {
  const {a,b,c,d,e,f,scale,dpr,W,H}=camera;
  const size=clamp(scale/62,.34,1.55)*(g.silver.tier===6?1.34:1);
  ctx.save();
  for(const q of g.shots) {
    const x=a*q.x+c*q.y+e, y=b*q.x+d*q.y+f-scale*.67;
    if(x< -100 || x>W+100 || y< -80 || y>H+80)continue;
    const vx=a*q.vx+c*q.vy,vy=b*q.vx+d*q.vy,len=Math.hypot(vx,vy);
    const ux=vx/len*dpr,uy=vy/len*dpr;
    ctx.setTransform(ux,uy,-uy,ux,x*dpr,y*dpr);
    ctx.drawImage(utensilTexture(q.kind),-104*size,-12*size,135*size,24*size);
  }
  ctx.restore();
}
// The pickup has a dark teal face and a silver fork, readable against both carpet and parquet.
function silverPickupTexture() {
  if(silverAtlas.has('pickup'))return silverAtlas.get('pickup');
  const tex=document.createElement('canvas');
  tex.width=tex.height=80;
  const pen=tex.getContext('2d');
  pen.translate(40,40);
  pen.beginPath();
  [[0,-33],[22,-19],[27,5],[0,34],[-27,5],[-22,-19]].forEach(([x,y],i)=>i?pen.lineTo(x,y):pen.moveTo(x,y));
  pen.closePath();
  const face=pen.createLinearGradient(0,-31,0,32);
  face.addColorStop(0,'#36c8c7');face.addColorStop(.55,'#08737b');face.addColorStop(1,'#003942');
  pen.fillStyle=face;pen.fill();
  pen.strokeStyle='#122633';pen.lineWidth=8;pen.stroke();
  pen.strokeStyle='#a0fff0';pen.lineWidth=3;pen.stroke();
  pen.rotate(.46);pen.lineCap='round';pen.strokeStyle='#072e3b';pen.lineWidth=7;
  function fork(){
    pen.beginPath();pen.moveTo(0,20);pen.lineTo(0,-5);
    pen.moveTo(-8,-18);pen.lineTo(-8,-9);pen.quadraticCurveTo(-8,-2,0,-2);
    pen.quadraticCurveTo(8,-2,8,-9);pen.lineTo(8,-18);
    pen.moveTo(0,-18);pen.lineTo(0,-6);pen.stroke();
  }
  fork();pen.strokeStyle='#fffbea';pen.lineWidth=3.7;fork();
  silverAtlas.set('pickup',tex);
  return tex;
}
function drawSilverDrops(g) {
  const radius=clamp(camera.scale*.28,13,19);
  const icon=silverPickupTexture();
  let nearest=null,range=Infinity;
  for(const drop of g.silverDrops) {
    const p=project(drop);
    if(p.x < -radius || p.x>camera.W+radius)continue;
    const pulse=Math.sin(g.tick*.074+drop.x*1.7+drop.y);
    const y=p.y-radius*(1.02+.19*pulse);
    ellipse(p.x,p.y,radius*.82,radius*.26,'#112c37c9',true);
    ellipse(p.x,p.y,radius*(.82+.12*pulse),radius*.27,'#abfff2',false,1.4);
    if (drop.order) {
      ctx.save();
      ctx.translate(p.x,y);
      ctx.rotate(-.13);
      ctx.fillStyle='#55263d';
      ctx.strokeStyle='#ffdc87';
      ctx.lineWidth=2;
      ctx.fillRect(-radius*.74,-radius,radius*1.48,radius*2);
      ctx.strokeRect(-radius*.74,-radius,radius*1.48,radius*2);
      ctx.font='bold '+radius+'px serif';
      ctx.textAlign='center';
      ctx.fillStyle='#fff0c2';
      ctx.fillText('♛',0,2);
      ctx.font='bold 9px sans-serif';
      ctx.fillText('오더',0,radius*.76);
      ctx.restore();
      continue;
    }
    ctx.drawImage(icon,p.x-radius,y-radius,2*radius,2*radius);
    if(pulse>.35){
      const x=p.x+radius*.71,sy=y-radius*.68;
      stroke(x,sy-4,x,sy+4,'#edfffc',1.7);stroke(x-4,sy,x+4,sy,'#edfffc',1.7);
    }
    const dist=distance(g.player,drop);
    if(dist<range){range=dist;nearest=p;}
  }
  if(!g.silver.count && nearest && range<4.1) {
    const label='은식기 파편 · 가까이 가서 줍기';
    ctx.font='bold 13px system-ui,sans-serif';ctx.textAlign='center';
    const width=ctx.measureText(label).width+18;
    const x=clamp(nearest.x,width/2+3,camera.W-width/2-3);
    const y=nearest.y+23;
    ctx.fillStyle='#082e38';ctx.fillRect(x-width/2,y-14,width,21);
    ctx.strokeStyle='#8cf4df';ctx.lineWidth=1;ctx.strokeRect(x-width/2,y-14,width,21);
    ctx.fillStyle='#effffa';ctx.fillText(label,x,y+1);
  }
}
