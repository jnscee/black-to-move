// These fixtures use the production Game class and the same integer clock as normal play.
// No global game, inputs, or RNG are modified. Run from Settings or from the browser console.
function runRules(seed = '1889') {
  const results = [];
  function test(name, body) {
    try{
      body();
      results.push({name, ok:true});
    }catch (e) {
      results.push({name, ok:false, error:e.message});
    }
  }
  function check(ok, why) {
    if (!ok)throw Error(why);
  }
  function equal(a, b) {
    check(JSON.stringify(a) === JSON.stringify(b), JSON.stringify(a) + ' ≠ ' + JSON.stringify(b));
  }
  function near(a, b) {
    check(Math.abs(a - b) < 1e-6, a + ' ≠ ' + b);
  }
  const fresh = () => new Game(seed, false);
  function quiet(g) {
    g.waves = [];
    g.warnings = [];
    g.enemies = [];
    g.cool = Infinity;
  }
  function ticks(g, n, input = point(0, 0)) {
    for (let i = 0;i < n;i++)g.step(input);
  }
  function recruit(key = 'meyrin') {
    const g = fresh();
    g.reward();
    check(g.choose(key), '첫 영입');
    quiet(g);
    return g;
  }
  function addForFixture(g, key) {
    g.roster[key] = 1;
    g.addCard(key);
    g.enter(1);
    quiet(g);
  }
  function shotFixture() {
    const g = recruit(), u = g.units[0];
    Object.assign(u, point(9, 6));
    g.facing = point(1, 0);
    for (const [x, y] of [[8, 6], [6, 6], [7, 6.32]])g.enemy('chaser', x, y);
    return g;
  }
  test('이동 속력 · 대각선 · 탑뷰와 등각 입력', () => {
    const a = fresh(), b = fresh();
    quiet(a);
    quiet(b);
    ticks(a, 60, point(1, 0));
    ticks(b, 60, point(1, 1));
    near(a.player.x, 5.2);
    near(distance(b.player, point(2, 6)), 3.2);
    const r = screenInput(1, 0, true), u = screenInput(0, -1, true);
    near(r.x + r.y, 0);
    near(u.x - u.y, 0);
    check(r.x > 0 && u.y < 0, '화면 방향');
  });
  test('벽·탁자 충돌 · 북쪽 우회로의 적 길찾기', () => {
    const g = fresh();
    quiet(g);
    g.player = point(8.2, 6);
    ticks(g, 180, point(1, 0));
    check(g.player.x <= 8.781, '탁자 관통');
    g.enter(1);
    quiet(g);
    g.player = point(13, 5.9);
    const e = g.enemy('chaser', 10, 2);
    for (let i = 0;i < 1050 && distance(e, g.player) > .55;i++) {
      g.moveEnemy(e);
      check(free(1, e, e.radius), '적이 벽 안으로 이동');
    }
    check(distance(e, g.player) < .6, '우회 실패');
  });
  test('은식기 사거리 · 동률 우선순위 · 0.8초 재사용', () => {
    const g = fresh();
    quiet(g);
    g.cool = 0;
    ticks(g, 80);
    equal(g.cool, 0);
    const a = g.enemy('chaser', 3, 6), b = g.enemy('chaser', 1, 6);
    a.speed = b.speed = 0;
    g.step();
    equal([a.hp, b.hp], [11, 18]);
    ticks(g, 47);
    equal(a.hp, 11);
    g.step();
    equal(a.hp, 4);
  });
  test('동시 접촉 시 패배 1회 · 승리 우선 · 재시작', () => {
    const a = recruit();
    a.hp = 1;
    a.enemy('chaser', 2, 6);
    a.enemy('chaser', 2, 6);
    a.units[0].ready = Infinity;
    ticks(a, 5);
    equal([a.phase, a.resultCount], ['loss', 1]);
    const b = fresh();
    b.enter(2);
    b.hp = 1;
    const boss = b.enemies[0];
    Object.assign(boss, {x:2, y:6, hp:7});
    b.enemy('chaser', 2, 6);
    b.step();
    equal([b.phase, b.resultCount, b.hp], ['win', 1, 1]);
    for (const ended of [a, b]) {
      const next = new Game(ended.seed);
      equal([next.hp, next.deck.length, next.units.length, next.room], [6, 4, 0, 0]);
    }
  });
  test('엄호 1회 소모 · 1.25초 무적 · 호위 유지', () => {
    const g = fresh();
    quiet(g);
    g.hand = [g.deck[0], g.deck[2]];
    g.phase = 'hand';
    g.order(g.deck[0].id);
    const a = g.enemy('chaser', 2, 6), b = g.enemy('chaser', 2, 6);
    a.speed = b.speed = 0;
    g.step();
    equal([g.shield, g.immune, g.hp], [0, 76, 6]);
    ticks(g, 74);
    equal(g.hp, 6);
    g.step();
    equal(g.hp, 5);
  });
  test('24.9초 잠금 · 25초 문 통과 · 연타 1회', () => {
    const g = fresh();
    quiet(g);
    g.tick = 1493;
    g.player = point(19, 6);
    g.step();
    equal([g.tick, g.door, g.phase], [1494, false, 'fight']);
    ticks(g, 6);
    equal([g.tick, g.phase, g.choice], [1500, 'reward', 1]);
    equal([...g.candidates].sort(), ['bard', 'finny', 'meyrin']);
    g.hp = 3;
    const t = g.choice;
    check(g.choose('meyrin', t), '선택 실패');
    check(!g.choose('meyrin', t), '중복 처리');
    equal([g.room, g.hp, g.units.length, g.deck.length], [1, 3, 1, 5]);
  });
  test('개방 뒤 추가 스폰 종료 · 남아 있는 적은 계속 이동', () => {
    const g = fresh();
    quiet(g);
    g.tick = 1499;
    const e = g.enemy('chaser', 3.5, 6), x = e.x;
    g.step();
    ticks(g, 15);
    check(g.door && g.phase === 'fight' && e.x < x, '문 또는 적');
    equal(g.log.spawns.length, 0);
  });
  test('복도 모퉁이 · 후미 궤적 · 복귀 속력 상한', () => {
    const g = recruit(), u = g.units[0];
    let max = 0;
    for (const [x, y, n] of [[0, -1, 75], [1, 0, 267], [0, 1, 75], [-1, 0, 22], [1, 0, 12]]) {
      for (let i = 0;i < n;i++) {
        const before = copyPoint(u);
        g.step(point(x, y));
        max = Math.max(max, distance(before, u));
        check(free(1, u, .17), '벽 속 동료');
      }
    }
    check(max <= 4.5 / 60 + 1e-7, '후미 순간이동');
    check(u.x > 14 && u.y > 4.5, '우회로를 돌아 복귀');
  });
  test('관통 사선 안 두 명 14 · 사선 밖 0', () => {
    const g = shotFixture();
    g.invoke('meyrin', false);
    equal(g.enemies.map(e => e.hp), [4, 4, 18]);
    equal(g.log.beams.at(-1).hits, 2);
  });
  test('메이린 영입 5장 · 강화 후 5장 · 후속탄 0.25초', () => {
    const g = recruit();
    g.reward();
    g.choose('meyrin');
    quiet(g);
    equal([g.deck.length, g.deck.filter(c => c.key === 'meyrin').length, g.units.length], [5, 1, 1]);
    equal(g.deck.find(c => c.key === 'meyrin').level, 2);
    const u = g.units[0];
    u.ready = Infinity;
    g.enemy('elite', u.x + 2, u.y).speed = 0;
    g.invoke('meyrin', true);
    ticks(g, 14);
    equal(g.log.beams.length, 1);
    g.step();
    equal(g.log.beams.map(b => b.tick), [0, 15]);
    equal(u.ready, Infinity);
  });
  test('스네이크 영입 6장 · 감속 40% · 합동 피해 19', () => {
    let g;
    for (let i = 0;i < 100;i++) {
      g = new Game(seed + '/' + i, false);
      g.reward();
      g.choose('meyrin');
      g.reward();
      if (g.candidates.includes('snake'))break;
    }
    check(g.choose('snake'), '스네이크 영입');
    equal([g.deck.length, g.units.length], [6, 2]);
    quiet(g);
    g.units.forEach(u => Object.assign(u, point(8, 6)));
    const e = g.enemy('chaser', 7, 6);
    g.invoke('snake', false);
    near(slowAt(g, e), .4);
    g.invoke('meyrin', false);
    equal(e.hp, -1);
    g.resolveDeaths();
    equal(g.enemies.length, 0);
  });
  test('메이린 Ⅱ 사선 확장 · 기본 공격과 명령 독립', () => {
    const g = shotFixture(), u = g.units[0];
    u.level = 2;
    u.ready = 130;
    g.invoke('meyrin', true);
    equal(g.enemies.map(e => e.hp), [4, 4, 4]);
    equal(u.ready, 130);
  });
  test('피니안 밀치기로 실제 불길 진입 · 중복 불길 단일 틱', () => {
    const g = recruit('finny');
    addForFixture(g, 'bard');
    const u = g.units.find(u => u.key === 'bard');
    Object.assign(u, point(4, 6));
    g.invoke('bard', false);
    g.invoke('bard', false);
    const e = g.enemy('elite', 3, 6);
    e.speed = 0;
    check(distance(e, u) > .8, '불길 밖');
    g.invoke('finny', true);
    near(e.x, 4);
    g.units.forEach(v => v.ready = Infinity);
    ticks(g, 30);
    equal(e.hp, 24);
    ticks(g, 90);
    equal(e.hp, 15);
  });
  test('스네이크 강약 감속 겹침과 만료 · 엘리자베스 전후 분담', () => {
    const g = shotFixture();
    addForFixture(g, 'snake');
    addForFixture(g, 'lizzy');
    g.facing = point(1, 0);
    g.units.forEach(u => Object.assign(u, point(8, 6)));
    const front = g.enemy('chaser', 9, 6), rear = g.enemy('chaser', 7, 6);
    g.invoke('snake', true);
    g.tick = 30;
    g.invoke('snake', false);
    near(slowAt(g, rear), .5);
    g.tick = 120;
    near(slowAt(g, rear), .4);
    g.invoke('lizzy', false);
    equal([front.hp, rear.hp], [6, 18]);
    g.invoke('meyrin', false);
    equal([front.hp, rear.hp], [6, -1]);
  });
  test('정예 처치 물자 1개 · 0.6m 회수 · 호위 상한', () => {
    const g = fresh();
    quiet(g);
    g.hp = 5;
    g.enemy('elite', 2.61, 6).hp = 0;
    g.resolveDeaths();
    g.resolveDeaths();
    equal(g.items.length, 1);
    g.step();
    equal(g.hp, 5);
    g.player.x = 2.02;
    g.step();
    equal([g.hp, g.items.length], [6, 0]);
    g.items.push(copyPoint(g.player));
    g.step();
    equal(g.hp, 6);
  });
  test('손패 10초 정지 · 드로 중 버린 더미만 섞기', () => {
    const g = new Game(seed);
    g.tick = g.nextHand - 1;
    g.shield = 750;
    g.immune = 760;
    g.enemy('chaser', 3, 6);
    g.step();
    equal(g.phase, 'hand');
    const snapshot = () => JSON.stringify([g.tick, g.enemies, g.cool, g.hp, g.immune, g.shield, g.choice]);
    const saved = snapshot();
    ticks(g, 600);
    equal(snapshot(), saved);
    g.order(null);
    g.draw = [g.deck[0]];
    g.discard = g.deck.slice(1);
    g.deal();
    equal(g.hand[0].id, g.deck[0].id);
    check(g.hand[1].id !== g.hand[0].id, '자기 손패 재추첨');
    g.order(null);
    equal(g.discard.length, 2);
  });
  test('동일 카드 2장 폐기 · 유효 표적 없는 공격 거절', () => {
    const g = fresh();
    quiet(g);
    g.draw = g.deck.slice(2);
    g.deal();
    equal(g.hand.map(c => c.key), ['open', 'open']);
    check(!g.order(g.hand[0].id), '무효 공격');
    g.order(null);
    equal(new Set(g.discard.map(c => c.id)).size, 2);
  });
  test('스폰 0.6초 예고 · 안전거리 · 일반/보스 상한', () => {
    const g = fresh();
    quiet(g);
    g.schedule({kind:'chaser', count:40, side:'E'});
    equal(g.warnings.length, 22);
    ticks(g, 35);
    equal(g.enemies.length, 0);
    g.step();
    equal(g.enemies.length, 22);
    check(g.log.spawns.every(s => distance({x:s[2], y:s[3]}, g.player) >= 2), '안전거리');
    g.enter(2);
    g.schedule({kind:'chaser', count:40, side:'E'});
    equal(g.warnings.length, 8);
  });
  test('돌진형 고정 예고·거리·정지·재사용', () => {
    const g = fresh();
    quiet(g);
    const e = g.enemy('charger', 5, 6);
    g.tick = 1;
    g.moveEnemy(e);
    equal([e.mode, e.until], ['warn', 49]);
    g.player = point(5, 9);
    for (g.tick = 2;g.tick < 49;g.tick++)g.moveEnemy(e);
    near(e.x, 5);
    for (g.tick = 49;g.tick < 76;g.tick++)g.moveEnemy(e);
    near(e.x, 2.75);
    near(e.y, 6);
    g.moveEnemy(e);
    equal([e.mode, e.until], ['rest', 142]);
    g.tick = 142;
    g.moveEnemy(e);
    equal([e.mode, e.until], ['chase', 322]);
  });
  test('보스 입장 손패 · 예고 0.9초 · 벽 정지 · 피해 배율', () => {
    const g = new Game(seed);
    g.roster.meyrin = 1;
    g.addCard('meyrin');
    g.enter(2);
    equal([g.phase, g.tick, g.enemies[0].x, g.units.length], ['hand', 0, 16, 1]);
    g.order(null);
    const e = g.enemies[0];
    Object.assign(e, point(.45, 6));
    g.player = point(.23, 6);
    g.tick = 180;
    g.moveEnemy(e);
    equal([e.mode, e.until], ['warn', 234]);
    g.tick = 234;
    g.moveEnemy(e);
    equal(e.mode, 'rest');
    damage(g, e, 7);
    near(e.hp, 149.5);
  });
  test('일반·보스 손패 일정 · 대국 시드 재현 · 덱 비교판', () => {
    function play(enabled) {
      const g = new Game(seed, enabled);
      g.hp = 6;
      const picks = [];
      for (let r = 0;r < 2;r++) {
        for (let i = 0;i < g.exitTick;i++) {
          g.immune = 999999;
          g.step();
          if (g.phase === 'hand')g.order(null);
        }
        g.player = point(19, 6);
        g.step();
        picks.push(g.candidates.slice());
        g.choose(r === 0?'meyrin':g.candidates[0]);
      }
      const spawns = g.log.spawns.slice();
      const bossTurns = g.log.hands.filter(h => h.room === 2).map(h => h.tick);
      if (enabled) {
        g.order(null);
        quiet(g);
        g.immune = 999999;
        ticks(g, 720);
        bossTurns.push(g.tick);
        g.order(null);
        ticks(g, 1500);
        bossTurns.push(g.tick);
        equal(bossTurns, [0, 720, 2220]);
        equal(g.phase, 'hand');
      }
      return {picks, spawns, hands:g.log.hands.filter(h => h.room < 2)};
    }
    const a = play(true), b = play(true), off = play(false);
    equal(a, b);
    equal(a.picks, off.picks);
    equal(a.spawns, off.spawns);
    equal(a.hands.map(h => h.tick), [600, 720, 1800, 2880]);
    equal(off.hands.length, 0);
  });
  test('확장 인물은 추첨에서 제외 · 표식 우선 · 소마와 아그니 추가 연타', () => {
    equal(trialKeys().slice().sort(), ['bard', 'finny', 'lizzy', 'meyrin', 'snake']);
    const g = fresh();
    quiet(g);
    g.units = ['lau', 'grell', 'soma', 'agni'].map(key => ({key, level:1, x:4, y:6, ready:Infinity}));
    const boss = g.enemy('boss', 5, 6), nearer = g.enemy('chaser', 4.5, 6);
    g.invoke('lau', false);
    equal(boss.markUntil, 180);
    g.invoke('grell', false);
    near(boss.hp, 160 - 18 * 1.3);
    near(nearer.hp, 18);
    g.invoke('soma', false);
    near(nearer.hp, 14);
    equal(g.pending.length, 2);
    ticks(g, 12);
    near(nearer.hp, 6);
    equal(g.pending.length, 0);
    // A support cast already triggered as an extra cannot schedule another extra cast.
    equal(g.invoke('soma', false, false, {extra:true}), false);
    equal(g.pending.length, 0);
  });
  test('2단계 피니안·바르도·엘리자베스·스네이크 고유 수치', () => {
    for (const key of ['finny', 'bard', 'lizzy', 'snake']) {
      const g = fresh();
      quiet(g);
      g.player = point(8, 3);
      g.trail = [point(6, 3), point(8, 3)];
      const u = {key, level:2, x:8, y:3, ready:Infinity};
      g.units = [u];
      if (key === 'finny') {
        const e = g.enemy('elite', 9.6, 3);
        g.invoke(key, true);
        near(e.hp, 27);
        near(e.x, 11.1);
      }
      if (key === 'bard') {
        g.invoke(key, true);
        equal(g.fires.map(f => [f.x, f.end]), [[8, 180], [7, 180], [6, 180]]);
      }
      if (key === 'lizzy') {
        const e = g.enemy('elite', 10.2, 3);
        g.invoke(key, true);
        near(e.hp, 16);
      }
      if (key === 'snake') {
        const list = [1, 1.3, 1.6, 1.9].map(d => g.enemy('chaser', 8 - d, 3));
        g.invoke(key, false);
        equal(list.map(e => slowAt(g, e)), [.4, .4, .4, 0]);
        g.invoke(key, true);
        equal(list[2].slows.at(-1).end, 180);
      }
    }
  });
  test('파편 획득 · 누적 단계 · 대열·덱 독립 · 새 판 초기화', () => {
    const g=fresh();
    quiet(g);
    const observed=[];
    for(let count=1;count<=60;count++){
      g.silverDrops=[{...g.player,born:g.tick}];
      const old=g.silver.tier;
      collectSilver(g);
      if(old!==g.silver.tier)observed.push(count);
    }
    equal(observed,SILVER_TIERS.slice(1).map(s=>s.need));
    equal([g.silver.count,g.silver.tier,g.silver.bursts,g.shots.length,g.deck.length],[60,6,1,48,4]);
    g.reward();g.choose('meyrin');
    equal([g.silver.count,g.silver.tier,g.shots.length,g.deck.length],[60,6,0,5]);
    const reset=fresh();equal([reset.silver.count,reset.silver.tier,reset.shots.length],[0,0,0]);
  });
  test('파편의 통로 배치 · 벽 너머 흡수 금지 · 스폰 난수 분리', () => {
    const a=fresh(),b=fresh();
    for(let room=0;room<3;room++){
      a.enter(room);b.enter(room);
      for(let n=0;n<25;n++)scatterSilver(a);
      check(a.silverDrops.every(p=>free(room,p,.16)),'막힌 자리에 파편 생성');
      equal(a.rng.wave(),b.rng.wave());equal(a.rng.reward(),b.rng.reward());equal(a.rng.deck(),b.rng.deck());
    }
    a.enter(0);a.silver.count=1;
    a.player=point(8.76,5.38);const beyond=point(9.39,4.76);a.silverDrops=[{...beyond,born:0}];
    for(let n=0;n<60;n++)collectSilver(a);
    equal([a.silverDrops[0].x,a.silverDrops[0].y,a.silver.count],[beyond.x,beyond.y,1]);
  });
  test('실제 탄도 충돌 · 한 발은 같은 적을 한 번만 관통', () => {
    const g=fresh();quiet(g);
    const a=g.enemy('chaser',3.2,6),b=g.enemy('chaser',4,6),outside=g.enemy('chaser',3.3,6.8);
    launchSilver(g,'knife',2,6,0,6,2,100,3);
    for(let i=0;i<35;i++){g.tick++;advanceSilver(g);}
    equal([a.hp,b.hp,outside.hp,g.silver.hits],[16,16,18,2]);
  });
  test('최고 단계 네 탄종 · 동시 탄막 180발 이상 · 손패 정지', () => {
    const g=fresh();quiet(g);g.player=point(10,3);g.silver.tier=6;g.silver.count=54;
    ticks(g,180);
    equal([...new Set(g.shots.map(q=>q.kind))].sort(),['fork','knife','rain','spoon']);
    check(g.silver.peak>=180,'최고 단계 탄막 밀도');
    g.deal();
    const frozen=JSON.stringify([g.shots,g.silverDrops,g.silverTimers,g.silver]);
    ticks(g,600);equal(JSON.stringify([g.shots,g.silverDrops,g.silverTimers,g.silver]),frozen);
  });
  return results;
}
