'use strict';
const $ = id => document.getElementById(id), sheet = $('sheet'), modal = $('modal'), held = new Set();
const options = {seed:'', commands:true, iso:false};
let game = null, stick = null, panels = [], lastPhase = '', lastRoom = -1, hudStamp = '', accumulator = 0, previous = 0, turnShows = 0, lastArrival = 0;
const escapeText = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'})[c]);
const fmt = t => Math.floor(t / 3600).toString().padStart(2, '0') + ':' + Math.floor(t / 60 % 60).toString().padStart(2, '0');
const cardName = c => TACTICS[c.key]?.name || COMMON[c.key]?.name || PIECES[c.key].command;
const activePanel = () => panels[panels.length - 1]?.kind;
function clearInput() {
  held.clear();
  stick = null;
  $('stick').hidden = true;
  accumulator = 0;
}
function drawer(kind, html, stack = false) {
  clearInput();
  if (!stack) {
    panels = [];
    sheet.replaceChildren();
  }else if (panels.length)panels.at(-1).el.hidden = true;
  const el = document.createElement('section');
  el.dataset.panel = kind;
  el.innerHTML = html;
  sheet.append(el);
  panels.push({kind, el});
  if (!modal.open)modal.showModal();
  const heading = el.querySelector('h2');
  if (heading) {
    heading.id = 'title-' + kind;
    modal.setAttribute('aria-labelledby', heading.id);
  }
  const focus = el.querySelector('[data-focus]') || el.querySelector('button:not(:disabled)');
  focus?.focus({preventScroll:true});
}
function dismiss(all = false) {
  clearInput();
  if (all) {
    panels = [];
    sheet.replaceChildren();
  }else panels.pop()?.el.remove();
  if (!panels.length) {
    if (modal.open)modal.close();
    if (game)field.focus({preventScroll:true});
  }
  else{
    const top = panels.at(-1);
    top.el.hidden = false;
    modal.setAttribute('aria-labelledby', 'title-' + top.kind);
    top.el.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
  }
  previous = performance.now();
}
const header = (en, title, action = 'close') => '<div class="dialog-head"><div><small class="eyebrow">' + en + '</small><h2>' + title + '</h2></div>' + (action?'<button class="minor" data-action="' + action + '">' + (action === 'pause'?'일시정지':'닫기') + '</button>':'') + '</div>';
function start() {
  dismiss(true);
  game = new Game(options.seed || String(crypto.getRandomValues(new Uint32Array(1))[0]), options.commands);
  view.iso = options.iso;
  document.body.classList.add('playing');
  $('cover').hidden = true;
  $('game').hidden = false;
  $('pause').hidden = false;
  lastPhase = '';
  lastRoom = -1;
  hudStamp = '';
  turnShows = 0;
  clearInput();
  sync();
  field.focus({preventScroll:true});
}
function home() {
  dismiss(true);
  game = null;
  document.body.classList.remove('playing');
  $('game').hidden = true;
  $('cover').hidden = false;
  $('pause').hidden = true;
  $('start').focus({preventScroll:true});
}
function formation() {
  const lead = '<span class="crew"><img src="' + MANOR.figures.hero1 + '" alt="">시엘 · 세바스찬</span>';
  return lead + game.units.map(u => '<span class="crew"><img alt="" src="' + MANOR.figures[u.key] + '">' + PIECES[u.key].name + (u.level === 2?' Ⅱ':'') + (game.orderRank?' +'+game.orderRank:'') + '</span>').join('');
}
function sync() {
  if (!game)return;
  const g = game, room = ROOMS[g.room], boss = g.enemies.find(e => e.kind === 'boss'), time = g.room === 2?Math.max(0, boss?.hp || 0) + ' / 160':fmt(g.tick);
  const s=g.silver, next=SILVER_TIERS[s.tier+1];
  const stamp = [g.room, time, g.hp, g.door, s.count,g.orderRank].join('|');
  $('bellAction').hidden = !g.canRing();
  const trainingButton = $('train');
  const canTrain = g.trainingLevel < 8 && g.xp >= g.xpNeeded;
  const label = canTrain ? '✦ 대열 강화 선택' : g.trainingLevel === 8 ? '대열 강화 완료' : '대열 Lv.'+(1+g.trainingLevel)+'　'+g.xp+' / '+g.xpNeeded;
  const meter = $('xpMeter');
  if (meter.max !== g.xpNeeded)meter.max = g.xpNeeded;
  const filled = g.trainingLevel === 8 ? g.xpNeeded : Math.min(g.xp,g.xpNeeded);
  if (meter.value !== filled)meter.value = filled;
  if (trainingButton.textContent !== label)trainingButton.textContent = label;
  trainingButton.disabled = !canTrain || g.phase !== 'fight';
  if (stamp !== hudStamp) {
    $('silverLevel').textContent = 'Lv.'+(s.tier+1);
    $('silverProgress').textContent = '파편 '+s.count+(next?'/'+next.need:' · MAX');
    $('silverLevel').parentElement.title = SILVER_TIERS[s.tier].name+' · 파편 '+s.count+'개';
    $('roomName').textContent = room.name;
    $('roomEn').textContent = ['I', 'II', 'III'][g.room] + ' / ' + room.en;
    $('hearts').innerHTML = Array.from({length:6}, (_, i) => '<i class="pip ' + (i >= g.hp?'empty':'') + '"></i>').join('');
    $('hearts').setAttribute('aria-label', '호위 ' + g.hp + '칸 / 6칸');
    $('clockName').textContent = g.room === 2?'보스 체력':'경과 시간';
    $('clock').textContent = time;
    $('door').textContent = g.room === 2?'보스 격파':g.door?'동쪽 출구 개방':'출구 개방까지 ' + Math.ceil((g.exitTick - g.tick) / 60) + '초';
    if ($('formation').dataset.order !== String(g.orderRank)) {
      $('formation').innerHTML = formation();
      $('formation').dataset.order = g.orderRank;
    }
    hudStamp = stamp;
  }
  if (lastRoom !== g.room) {
    $('formation').innerHTML = formation();
    lastRoom = g.room;
    lastArrival = 120;
    $('arrival').textContent = g.room === 0?'':g.room === 1?g.units[0] && PIECES[g.units[0].key].name + ' 합류 · 북쪽 호출종으로 출구 조기 개방':'연회장 진입 · 돌진 예고에 주의';
  }
  const notice=g.lastSilverNotice;
  const activeStances=Object.entries(g.stances).filter(([,state])=>state.until>g.tick)
    .map(([type,state])=>SCHOOLS[type].name+' '+Math.ceil((state.until-g.tick)/60)+'초');
  const growthText=notice && g.tick-notice.tick<105?notice.text:activeStances.join(' · ');
  if($('growth').textContent!==growthText)$('growth').textContent=growthText;
  if (g.tick >= lastArrival)$('arrival').textContent = '';
  if (g.phase !== lastPhase) {
    lastPhase = g.phase;
    if (g.phase === 'hand' || g.phase === 'reward')showTurn();
    if (g.phase === 'win' || g.phase === 'loss')showResult();
  }
}
const reasons = {snare:"6m 안에 적이 없습니다.",quarry:"8m 안에 적이 없습니다.",open:'정면 2m 안에 적이 없습니다.', meyrin:'6m 안에 조준할 적이 없습니다.', finny:'시엘 주위에 적이 없습니다.', snake:'스네이크 4m 안에 적이 없습니다.', lizzy:'전방 검격 범위에 적이 없습니다.'};
function showTurn() {
  const g = game, isReward = g.phase === 'reward';
  turnShows++;
  let body = header(isReward?'NEXT PIECE':'COMMAND HAND', isReward?'다음 말을 두세요':'시엘의 명령', 'pause');
  const next = ROOMS[g.room + 1];
  body += isReward?'<p class="intro">다음 구역 · <b>' + next.name + '</b><br>' + next.note + '</p>':'<p class="intro">' + ROOMS[g.room].name + ' · ' + fmt(g.tick) + '　전투 정지 중</p>';
  body += '<p class="turnline new" lang="en">' + TURN_LINE + '</p>';
  if (isReward) {
    if (g.commands) {
      body += '<label class="settings-line">덱 계통 <select id="schoolPick">';
      for (const key of g.schoolOffers) {
        const school=SCHOOLS[key];
        const advanced=g.schoolPicks.includes(key), card=TACTICS[school.cards[advanced?1:0]];
        body += '<option value="'+key+'">'+school.name+(advanced?' Ⅱ':' Ⅰ')+' · '+card.name+'</option>';
      }
      body += '</select></label><p class="intro" id="schoolPreview"></p>';
    }
    body += '<div class="choices recruit">';
    for (const [index, key] of g.candidates.entries()) {
      const p = PIECES[key], up = !!g.roster[key];
      body += '<button class="card" data-pick="' + key + '" data-token="' + g.choice + '"><span class="portrait" style="--t:' + p.color + '"><img src="' + MANOR.portraits[key] + '" alt=""><span class="chess">' + p.piece + '</span></span><span class="cardcopy"><small>' + p.en + ' · ' + p.role + '</small><strong>' + p.name + '</strong><span class="text">' + (up?'Ⅱ 강화 · ' + p.upgrade:'영입 · ' + p.basic) + '</span></span><span class="key">' + (index + 1) + '</span></button>';
    }
    body += '</div>';
  }else{
    body += '<div class="choices short" style="--n:' + g.hand.length + '">';
    for (const [i, c] of g.hand.entries()) {
      const ok = g.can(c), p = PIECES[c.key];
      const enhanced = {
        meyrin:'0.25초 뒤 두 번째 관통탄을 발사합니다.',
        finny:'반경 1.7m의 적을 1.5m 밀칩니다.',
        bard:'지나온 길에 불길 세 개가 3초간 남습니다.',
        snake:'4m 안의 적 셋을 3초간 50% 늦춥니다.',
        lizzy:'전방 140도·2.3m 안의 적에게 피해 20을 줍니다.'
      };
      body += '<button class="card" data-card="' + c.id + '" data-token="' + g.choice + '" ' + (ok?'':'disabled') + '><span class="cardcopy"><small>' + (p?p.name + (c.level === 2?' · Ⅱ 강화':' · 고유 명령'):TACTICS[c.key]?Object.values(SCHOOLS).find(s=>s.cards.includes(c.key)).name+' · 계통 명령':'시엘 · 기본 명령') + '</small><strong>' + cardName(c) + '</strong><span class="text">' + (TACTICS[c.key]?.effect || COMMON[c.key]?.effect || (c.level === 2?enhanced[c.key]:p.effect)) + '</span>' + (!ok?'<span class="why">' + reasons[c.key] + '</span>':'') + '</span><span class="key">' + (i + 1) + '</span></button>';
    }
    body += '</div>';
  }
  body += '<div class="dlgfoot"><span class="piles">' + (isReward?'현재 명령 덱 ' + g.deck.length + '장':(g.schoolPicks.length?g.schoolPicks.map(k=>SCHOOLS[k].name).join(' → ')+' · ':'')+'뽑을 더미 ' + g.draw.length + ' · 손패 ' + g.hand.length + ' · 버린 더미 ' + g.discard.length) + '</span>' + (isReward?'':'<button class="minor" data-skip data-token="' + g.choice + '">지금은 됐다</button>') + '</div>';
  drawer(g.phase, body);
  const select=$('schoolPick');
  if (select) {
    const preview=()=>{
      const school=SCHOOLS[select.value];
      const card=TACTICS[school.cards[g.schoolPicks.includes(select.value)?1:0]];
      $('schoolPreview').textContent=card.effect+' 말을 고르면 '+(g.room?'길을 열어':'엄호해')+' 1장을 교체하고 다음 첫 손패에 받습니다.';
    };
    select.onchange=preview;
    preview();
  }
}
$('bellAction').onclick = () => {
  if (game && !modal.open && game.ringBell())sync();
};
$('train').onclick = () => {
  if (!game || game.phase !== 'fight' || modal.open || game.xp < game.xpNeeded)return;
  showTraining();
};
function showTraining() {
  const icons = {volley:'♗',stride:'♘',ward:'♜',reach:'♙'};
  const roles = {volley:'지원 사격',stride:'이동 공격',ward:'방어',reach:'수집'};
  const cards = game.trainingOffers().map((key,i) => {
    const rank = game.training[key] || 0, item = TRAINING[key];
    return '<button class="card" data-training="'+key+'"><span class="perk-icon" aria-hidden="true">'+icons[key]+'</span><span class="cardcopy"><small>'+roles[key]+' · '+(rank ? '강화 Ⅰ → Ⅱ' : '신규 Ⅰ')+'</small><strong>'+item.name+'</strong><span class="text">'+item.text[rank]+'</span></span><span class="key">'+(i+1)+'</span></button>';
  });
  const canRedraw = game.redraws > 0 && Object.keys(TRAINING).filter(k => (game.training[k] || 0) < 2).length > 3;
  drawer('training',header('FORMATION','대열 강화')+'<p class="intro">레벨 '+(game.trainingLevel+1)+' → '+(game.trainingLevel+2)+'</p><div class="choices perk-grid" style="--n:'+cards.length+'">'+cards.join('')+'</div><div class="dlgfoot"><button class="minor" data-redraw '+(canRedraw?'':'disabled')+'>후보 교체 · '+game.redraws+'회</button><button class="minor" data-action="close">나중에 선택</button></div>');
}
function selectChoice(b) {
  if (!game || !b || b.disabled)return;
  const k = activePanel(), token = Number(b.dataset.token);
  if (k === 'training') {
    if (b.hasAttribute('data-redraw') && game.redrawTraining()) { showTraining(); return; }
    if (game.train(b.dataset.training)) { dismiss(); sync(); }
    return;
  }
  if (k !== 'hand' && k !== 'reward')return;
  let accepted = false;
  if (k === 'reward' && b.hasAttribute('data-pick'))accepted = game.choose(b.dataset.pick, token, $('schoolPick')?.value || null);
  if (k === 'hand' && (b.hasAttribute('data-card') || b.hasAttribute('data-skip')))
  accepted = game.order(b.hasAttribute('data-skip')?null:Number(b.dataset.card), token);
  if (accepted) {
    dismiss(true);
    lastPhase = '';
    sync();
    paint(game);
  }
}
function pauseGame() {
  if (!game || activePanel() === 'pause' || game.ended)return;
  drawer('pause', header('INTERMISSION', '일시정지', '') + '<p class="intro">' + ROOMS[game.room].name + ' · ' + fmt(game.tick) + '</p><div class="dlgfoot"><button class="primary" data-action="close">계속하기</button><button class="minor" data-action="settings">설정</button><button class="minor" data-action="leave">타이틀로</button></div>', true);
}
function showHelp() {
  drawer('help', header('HOW TO PLAY', '조작 안내') + '<dl class="scrolltext"><dt>이동과 공격</dt><dd>WASD·방향키로 이동하세요. 터치 화면에서는 전투판을 누른 채 원하는 방향으로 드래그하세요. 세바스찬은 5m 안의 가장 가까운 적에게 자동으로 은식기를 던집니다. 금색 발밑 원이 피격 범위입니다.</dd><dt>대열 강화</dt><dd>쓰러진 적이 남긴 보라색 결정을 주우세요. 경험치가 차면 전투판 하단의 대열 강화 선택을 눌러 이번 판에 쓸 능력을 고릅니다.</dd><dt>사용인 오더 카드</dt><dd>사용인이 합류하면 금테 왕관 카드가 떨어집니다. 주울 때마다 모든 사용인의 기본 공격이 빨라지고 각자의 기술이 강화됩니다. 최대 6단계이며 다음 방까지 이어집니다.</dd><dt>세바스찬의 은식기</dt><dd>청록색 포크 아이콘에 다가가 파편을 모으세요. 총 ' + SILVER_TIERS.slice(1).map(t=>t.need).join('·') + '개에서 쌍투, 부채 투척, 회전 나이프, 이중 나선, 은빛 소나기, 은식기 폭풍이 차례로 열립니다. 파편은 바닥과 쓰러진 적에게서 얻습니다. 모은 파편은 다음 방에 이어지며, 최고 단계에서는 여섯 개마다 추가 일제 사격이 나갑니다.</dd><dt>현관홀과 서재 회랑</dt><dd>현관홀은 25초, 서재 회랑은 60초에 동쪽 문이 열립니다. 회랑 북쪽의 호출종에 다가가 울리면 정예가 등장합니다. 그 정예를 처치하면 문이 즉시 열립니다. 남은 적을 피해 문 안쪽의 원에 들어가세요. 정예가 남긴 구급상자는 호위를 한 칸 회복합니다.</dd><dt>시엘의 차례</dt><dd>카드를 누르거나 숫자 1·2·3으로 고르세요. 현관홀 10초와 서재 회랑 12·30·48초에 명령 두 장을 받고 하나를 쓰거나 넘깁니다. 출구에서는 다음 방에 가져갈 말을 고릅니다.</dd><dt>연회장</dt><dd>바닥에 붉은 선이 나타나면 옆으로 비키세요. 돌진 후 보스가 멈춘 동안 공격하면 피해가 1.5배가 됩니다. 호위 여섯 칸을 모두 잃으면 게임이 끝납니다.</dd><dt>잠시 멈추기</dt><dd>Esc로 일시정지하거나 이전 창으로 돌아갑니다. 전투판을 드래그하던 손은 뗀 뒤 새로 눌러 카드를 선택하세요.</dd></dl>', true);
}
function settings() {
  const html = header('OPTIONS', '게임 설정') + '<label class="settings-line">대국 시드 <input id="seed" type="text" maxlength="70" placeholder="비우면 매 판 무작위" value="' + escapeText(options.seed) + '" autocomplete="off"></label><label class="settings-line">시엘의 명령 덱 <input id="useDeck" type="checkbox" ' + (options.commands?'checked':'') + '></label><p class="intro">시드와 명령 덱 설정은 다음 판부터 적용됩니다.</p><label class="settings-line">개발용 시점 비교 <select id="projection"><option value="top">탑뷰</option><option value="iso" ' + (options.iso?'selected':'') + '>아이소메트릭</option></select></label><div class="dlgfoot"><button class="minor" data-action="tests">규칙 테스트 실행</button><button class="primary" data-action="save">설정 적용</button></div>';
  drawer('settings', html, true);
}
function saveSettings() {
  options.seed = $('seed').value.trim();
  options.commands = $('useDeck').checked;
  view.iso = options.iso = $('projection').value === 'iso';
  dismiss();
  if (game)paint(game);
}
function showTests() {
  const results = runRules($('seed')?.value.trim() || options.seed), passed = results.filter(r => r.ok).length;
  drawer('tests', header('SIMULATION CHECK', '규칙 테스트') + '<p>' + passed + ' / ' + results.length + ' 통과</p><p class="intro">한 틱은 1/60초입니다. 현재 게임과 독립된 게임 상태에서 검사합니다.</p><div class="testlog">' + results.map(r => escapeText((r.ok?'✓ ':'✗ ') + r.name + (r.ok?'':' — ' + r.error))).join('\n') + '</div>', true);
}
function showCredits() {
  drawer('credits', header('CREDITS', '제작 리소스') + '<div class="scrolltext"><p>《흑집사》의 인물과 세계를 바탕으로 만든 비공식 팬게임입니다.</p><dl><dt>표지와 영입 카드</dt><dd>Black to Move를 위해 제작한 저택 야경 삽화와 동료 다섯 명의 초상입니다.</dd><dt>전장과 인물</dt><dd>저택 실내 세 곳, 가구, 주인공 보행과 전투 인물은 이 게임의 저택판에서 제작한 그림입니다.</dd><dt>전투 효과와 화면</dt><dd>포크·나이프·스푼, 은식기 파편, 돌진 예고, 체스판 테두리와 단추는 게임 코드로 그립니다.</dd></dl></div>', true);
}
function showResult() {
  const g = game, won = g.phase === 'win';
  let html = header(won?'CHECKMATE':'GAME OVER', won?'체크메이트':'호위 실패', '') + '<p class="intro">' + (won?'연회장의 비자르 돌을 쓰러뜨렸습니다.':'비자르 돌이 호위를 뚫었습니다.') + '</p><div class="tally"><div><small>격파</small><strong>' + g.kills + '</strong></div><div><small>남은 호위</small><strong>' + g.hp + ' / 6</strong></div><div><small>명령 덱</small><strong>' + g.deck.length + '장</strong></div></div>';
  html += '<p class="copy">시드 '+escapeText(g.seed)+' · '+(g.schoolPicks.map(k=>SCHOOLS[k].name).join(' → ')||'계통 미선택')+'</p><p class="copy">세바스찬의 은식기　Lv.'+(g.silver.tier+1)+' · '+SILVER_TIERS[g.silver.tier].name+' · 파편 '+g.silver.count+'개</p>';
  html += '<p class="copy">둔 말　' + (g.log.picks.map(p => PIECES[p.key].name + (p.level === 2?' Ⅱ':'')).join(' → ') || '없음') + '<br>사용한 명령　' + (g.log.commands.map(c => cardName(c)).join(' · ') || '없음') + '</p>';
  if(g.trainingLevel)html += '<p class="copy">대열 강화　'+Object.entries(g.training).map(([key,rank])=>TRAINING[key].name+' '+(rank===2?'Ⅱ':'Ⅰ')).join(' · ')+'</p>';
  html += g.log.rooms.map(s => '<div class="logline"><span>' + ROOMS[s.room].name + '</span><span>' + fmt(s.elapsed) + ' · 피격 ' + s.hits + '회</span></div>').join('');
  html += '<div class="dlgfoot"><button class="primary" data-action="retry">재도전</button><button class="minor" data-action="home">타이틀로</button></div>';
  drawer('result', html);
}
function confirmLeave() {
  drawer('leave', header('RETURN TO TITLE', '타이틀로 돌아갈까요?', '') + '<p class="intro">이번 대열과 명령 덱은 게임을 끝내면 사라집니다.</p><div class="dlgfoot"><button class="minor" data-action="close">계속하기</button><button class="primary" data-action="home">타이틀로</button></div>', true);
}
const actions = {pause:pauseGame, close:() => dismiss(), retry:start, home, settings, save:saveSettings, tests:showTests, leave:confirmLeave};
let pressed = null;
sheet.addEventListener('pointerdown', e => {
  pressed = e.target.closest('button');
});
sheet.addEventListener('pointercancel', () => {
  pressed = null;
});
sheet.addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b || b.disabled)return;
  if (e.detail > 0 && (pressed !== b || e.detail > 1))return;
  pressed = null;
  if (b.dataset.action)actions[b.dataset.action]?.();else selectChoice(b);
});
modal.addEventListener('cancel', e => {
  e.preventDefault();
  if (['reward', 'hand'].includes(activePanel()))
  pauseGame();else if (activePanel() !== 'result')dismiss();
});
$('start').onclick = start;
Promise.all(assetsReady).then(() => {
  $('start').disabled = false;
}).catch(() => {
  $('start').textContent = '그림을 열 수 없습니다. 파일을 다시 열어 주세요.';
});
$('help').onclick = showHelp;
$('config').onclick = settings;
$('credits').onclick = showCredits;
$('pause').onclick = pauseGame;
const moveKeys = new Set(['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright']);
window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if (modal.open) {
    if (e.repeat || !['hand', 'reward', 'training'].includes(activePanel()))return;
    if (['1', '2', '3'].includes(k)) {
      e.preventDefault();
      selectChoice(panels.at(-1).el.querySelectorAll('.card')[Number(k) - 1]);
    }
    return;
  }
  if (!game)return;
  if (k === 'escape') {
    e.preventDefault();
    pauseGame();
  }
  else if (moveKeys.has(k)) {
    e.preventDefault();
    held.add(k);
  }
});
window.addEventListener('keyup', e => held.delete(e.key.toLowerCase()));
function touchStick(e) {
  const dx = e.clientX - stick.sx, dy = e.clientY - stick.sy, n = Math.hypot(dx, dy), r = 26, k = n > r?r / n:1;
  stick.x = n < 3?0:dx * k / r;
  stick.y = n < 3?0:dy * k / r;
  $('stick').firstElementChild.style.transform = 'translate(calc(-50% + ' + dx * k + 'px),calc(-50% + ' + dy * k + 'px))';
}
field.addEventListener('pointerdown', e => {
  if (!game || game.phase !== 'fight' || modal.open || stick)return;
  e.preventDefault();
  field.setPointerCapture(e.pointerId);
  field.focus({preventScroll:true});
  const b = field.getBoundingClientRect();
  stick = {id:e.pointerId, sx:e.clientX, sy:e.clientY, x:0, y:0};
  Object.assign($('stick').style, {left:e.clientX - b.left + 'px', top:e.clientY - b.top + 'px'});
  $('stick').hidden = false;
  touchStick(e);
});
field.addEventListener('pointermove', e => {
  if (stick && e.pointerId === stick.id)touchStick(e);
});
for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture'])field.addEventListener(ev, e => {
  if (stick?.id === e.pointerId) {
    stick = null;
    $('stick').hidden = true;
  }
});
function autoPause() {
  clearInput();
  if (game && !game.ended && (!modal.open || ['hand', 'reward'].includes(activePanel())))pauseGame();
}
window.addEventListener('blur', () => {
  if (navigator.maxTouchPoints > 0 && !document.hidden) {
    held.clear();
    return;
  }
  autoPause();
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden)autoPause();
});
function input() {
  const yes = (a, b) => Number(held.has(a) || held.has(b));
  const x = yes('d', 'arrowright') - yes('a', 'arrowleft'), y = yes('s', 'arrowdown') - yes('w', 'arrowup');
  return screenInput(x || y?x:stick?.x || 0, x || y?y:stick?.y || 0, view.iso);
}
function frame(now) {
  if (game) {
    if (!modal.open && game.phase === 'fight') {
      accumulator += Math.min(.2, Math.max(0, (now - (previous || now)) / 1000));
      while (accumulator + 1e-9 >= DT && game.phase === 'fight') {
        accumulator -= DT;
        game.step(input());
      }
      sync();
    }else accumulator = 0;
    if (!modal.open || lastPaint !== game.tick || lastPaintRoom !== game.room) {
      paint(game);
      lastPaint = game.tick;
      lastPaintRoom = game.room;
    }
  }
  previous = now;
  requestAnimationFrame(frame);
}
let lastPaint = -1, lastPaintRoom = -1;
window.addEventListener('resize', () => {
  if (game)paint(game);
});
requestAnimationFrame(frame);
