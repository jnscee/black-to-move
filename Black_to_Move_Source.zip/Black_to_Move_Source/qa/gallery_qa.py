"""Run against the built HTML with Playwright Chromium. CHROMIUM may point to a local browser."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright

with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path=os.getenv("CHROMIUM"))
    for mobile in (False, True):
        page = browser.new_page(has_touch=mobile, is_mobile=mobile,
                                viewport={"width": 390 if mobile else 1280, "height": 844})
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto((Path(__file__).resolve().parents[1] / "Black_to_Move.html").as_uri())
        def press(selector):
            page.wait_for_timeout(550)
            button = page.locator(selector).first
            button.tap() if mobile else button.click()
        press("#start")
        results = page.evaluate("runRules('116')")
        assert all(r["ok"] for r in results), results
        page.evaluate("game.reward();sync()")
        press("[data-pick=meyrin]")
        page.evaluate("game.tick=1319;game.step();sync()")
        press("[data-pick]:not([data-pick=meyrin])")
        page.wait_for_function("game.phase==='fight'", timeout=2000)
        assert page.evaluate("game.room===1 && game.reinforced && game.units.length===2 && game.deck.length===6 && game.tick<1500")
        for index, clock in [(0, 1500), (1, 5400)]:
            page.evaluate("([i,t])=>{game.tick=t;game.player=copyPoint(game.searches[i]);sync()}", [index,clock])
            press("#searchAction")
            assert page.evaluate("game.revisions.length") == index+1
            assert page.locator("#searchAction").is_hidden()
        page.evaluate("game.tick=6290;game.player=copyPoint(game.bell);sync()")
        assert page.evaluate("!game.canRing()")
        page.evaluate("game.tick=6310;sync()")
        press("#bellAction")
        assert page.evaluate("game.bell.state==='called'")
        page.evaluate("game.tick=8999;game.player=point(19,6);game.step();sync()")
        assert page.evaluate("game.room===2 && game.phase==='hand'")
        assert not errors, errors
        print("mobile" if mobile else "desktop", len(results), "rules and gallery UI passed")
        page.close()
