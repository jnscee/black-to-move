"""Check layout before, during and after earning a formation upgrade."""
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

page_url = (Path(__file__).resolve().parents[1] / "Black_to_Move.html").as_uri()
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path=os.getenv("CHROMIUM"))
    for width, height in [(1280, 800), (390, 844), (320, 640), (844, 390)]:
        page = browser.new_page(viewport={"width": width, "height": height}, has_touch=width < 1000)
        page.goto(page_url)
        page.click("#start")
        def boxes():
            return page.evaluate("""() => ['#arena', '.xp-rail', '#train', '.combat-foot'].map(s => {
                const {x,y,width,height}=document.querySelector(s).getBoundingClientRect();
                return [x,y,width,height];
            })""")
        before = boxes()
        page.evaluate("game.xp=game.xpNeeded;sync()")
        ready = boxes()
        assert before == ready, (width, before, ready)
        assert ready[2][3] >= 44
        page.click("#train")
        page.locator("[data-training]").first.click()
        assert boxes() == before and page.evaluate("game.trainingLevel===1")
        print(width, height, "stable")
        page.close()
