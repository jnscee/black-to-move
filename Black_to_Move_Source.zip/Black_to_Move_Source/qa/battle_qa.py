"""Browser replay with native key presses and card clicks; only the display clock is controlled."""
from pathlib import Path
import json,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
HTML=Path(sys.argv[1] if len(sys.argv)>1 else ROOT.parent/'Black_to_Move.html').resolve()
import os
CHROME=os.environ.get('BLACK_MOVE_CHROME')
clock="""
(() => {
  let timestamp=1000, callback;
  Object.defineProperty(performance,'now',{value:()=>timestamp});
  window.requestAnimationFrame=fn=>{callback=fn;return 1};
  window.qaFrames=n=>{
    for(let i=0;i<n;i++){timestamp+=1000/60;if(callback)callback(timestamp);}
  };
})();
"""
def run():
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=CHROME,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1280,'height':800})
  errors=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:external.append(r.url) if r.url.startswith(('http:','https:')) else None)
  page.add_init_script(clock);page.goto(HTML.as_uri());page.wait_for_selector('#start:enabled');page.evaluate('qaFrames(1)')
  page.locator('#start').click(force=True)
  page.evaluate('window.qaRoute = '+(ROOT/'route.js').read_text().strip()+';window.qaRoute=qaRoute();void 0')
  keys=set();phases=[];steps=0;lastroom=-1;visible_peak=0;peak_by_room=[0,0,0]
  while steps<16000:
   g=page.evaluate('({phase:game.phase,room:game.room,tick:game.tick,hp:game.hp})');phase=g['phase']
   if phase in ('win','loss'):break
   if phase in ('hand','reward'):
    phases.append(g)
    for k in keys:page.keyboard.up(k)
    keys=set()
    if phase=='reward':
     print('reward',g,flush=True)
     page.locator('[data-pick=meyrin]').click(force=True)
    else:
     choice=page.evaluate("(()=>{const c=game.hand.find(c=>c.key==='meyrin'&&game.can(c))||game.hand.find(c=>game.can(c));return c?.id||0;})()")
     page.locator('[data-card="'+str(choice)+'"]' if choice else '[data-skip]').click(force=True)
    continue
   if lastroom!=g['room']:
    print('room',g,flush=True);lastroom=g['room']
   if g['tick']%24 < 6:
    visible=page.evaluate('game.shots.filter(q=>{const p=project(q),y=p.y-camera.scale*.67;return p.x>=0&&p.x<=camera.W&&y>=0&&y<=camera.H;}).length')
    peak_by_room[g['room']]=max(visible,peak_by_room[g['room']])
    if visible>visible_peak:
     visible_peak=visible
     capture=os.environ.get('BLACK_MOVE_BARRAGE_SCREEN')
     if capture and visible>140:page.screenshot(path=capture)
   target=set(page.evaluate('qaRoute(game)'))
   for k in keys-target:page.keyboard.up(k)
   for k in target-keys:page.keyboard.down(k)
   keys=target
   page.evaluate('qaFrames(6)');steps+=6
  result=page.evaluate('({phase:game.phase,hp:game.hp,kills:game.kills,rooms:game.log.rooms,picks:game.log.picks,hands:game.log.hands,orders:game.log.commands,volley:game.log.beams.filter(x=>x.room===1&&x.hits>=2),deck:game.deck.length,silver:game.silver,turnShows})')
  result['visiblePeakByRoom']=peak_by_room
  print('RESULT',json.dumps({k:v for k,v in result.items() if k not in ('hands','orders','volley','silver')},ensure_ascii=False), 'volleys',len(result['volley']),flush=True)
  assert result['phase']=='win' and result['deck']==5 and result['silver']['tier']==6 and result['silver']['hits']>0 and visible_peak>=160
  assert page.locator('#modal').get_by_role('heading',name='체크메이트').is_visible()
  page.get_by_role('button',name='재도전').click(force=True)
  assert page.evaluate("game.deck.length===4&&game.units.length===0&&game.hp===6&&game.room===0&&game.silver.count===0&&game.shots.length===0")
  for _ in range(180):
   state=page.evaluate('game.phase')
   if state=='loss':break
   if state=='hand':page.locator('[data-skip]').click(force=True)
   page.evaluate('qaFrames(60)')
  assert page.evaluate("game.phase==='loss'&&game.resultCount===1")
  page.get_by_role('button',name='재도전').click(force=True)
  assert page.evaluate('game.hp===6&&game.kills===0&&game.deck.length===4&&game.units.length===0')
  assert not errors and not external,(errors,external)
  (ROOT/'battle_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
  print('win/retry and loss/retry passed; no remote requests or page errors',flush=True)
  browser.close()
if __name__=='__main__':run()
