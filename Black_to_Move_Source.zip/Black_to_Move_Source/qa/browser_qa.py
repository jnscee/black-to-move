"""Real browser controls and wall clock. Set BLACK_MOVE_CHROME to use an installed Chromium."""
import json,os,sys,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
HTML=Path(sys.argv[1] if len(sys.argv)>1 else ROOT.parent/'Black_to_Move.html').resolve()
CHROME=os.environ.get('BLACK_MOVE_CHROME')
def run():
 with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path=CHROME,args=['--no-sandbox']);rows=[];errors=[]
  mobile=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,has_touch=True,is_mobile=True)
  mobile.on('pageerror',lambda e:errors.append(str(e)))
  mobile.goto(HTML.as_uri());assert mobile.title()=='Black to Move'
  assert mobile.locator('h1').inner_text().replace('\n',' ').split()==['Black','to','Move']
  mobile.wait_for_selector('#start:enabled')
  assert mobile.locator('#cover').inner_text().splitlines().count('팬텀하이브 저택')==1
  assert mobile.locator('.surround').evaluate("(node) => getComputedStyle(node).borderImageSource==='none' && getComputedStyle(document.querySelector('.estate')).backgroundImage.includes('data:image/webp')")
  assert mobile.evaluate("Object.keys(pictures.portraits).length===5 && Object.values(pictures.figures).length===11 && Object.values(pictures).every(group=>Object.values(group).every(im=>im.complete&&im.naturalWidth>0))")
  assert mobile.evaluate("ROOMS.map(r=>r.name).join(',')==='현관홀,서재 회랑,연회장' && [0,1,2].every(room=>floorArt(room)?.width>0)")
  rows.append('새 표지·직선 테두리·새 초상 5장·실내 3곳·전투 인물·가구 오프라인 로드')
  mobile.locator('#start').tap();cdp=mobile.context.new_cdp_session(mobile)
  def touch(kind,x=0,y=0):
   cdp.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':[] if kind=='touchEnd' else [{'x':x,'y':y,'id':7}]})
  assert mobile.evaluate("game.silverDrops.length===11 && game.silver.count===0")
  before=mobile.evaluate('game.player.x')
  touch('touchStart',130,320);touch('touchMove',185,320);mobile.wait_for_timeout(550);touch('touchEnd')
  after=mobile.evaluate('game.player.x');assert after-before>1.05
  mobile.wait_for_function('game.silver.count>=1');assert mobile.locator('#silverLevel').inner_text()=='Lv.2'
  assert mobile.locator('#silverProgress').inner_text()=='파편 1/5'
  rows.append('390×844 실시간 터치 드래그로 첫 파편 획득 및 Lv.2 표시')
  mobile.wait_for_function('game.tick>=665');touch('touchStart',145,340);touch('touchMove',177,340)
  mobile.wait_for_selector('[data-skip]');card=mobile.locator('[data-skip]').bounding_box()
  touch('touchMove',int(card['x']+20),int(card['y']+12));touch('touchEnd');mobile.wait_for_timeout(200)
  assert mobile.evaluate("game.phase==='hand'&&turnShows===1")
  rows.append('이동 드래그를 넘기기 버튼에서 놓아도 손패 유지')
  state="JSON.stringify([game.tick,game.enemies,game.cool,game.hp,game.immune,game.shield,game.units,game.warnings,game.silver,game.shots,game.silverDrops,game.silverTimers])"
  a=mobile.evaluate(state);mobile.wait_for_timeout(10030);assert mobile.evaluate(state)==a
  rows.append('실시간 10초간 손패 정지')
  mobile.evaluate('window.originalQuote=document.querySelector(".turnline")')
  mobile.locator('button[data-action=pause]').tap();mobile.get_by_role('button',name='계속하기').tap()
  assert mobile.evaluate('turnShows===1&&document.querySelector(".turnline")===window.originalQuote')
  mobile.locator('[data-skip]').tap()
  # Only this boundary layout fixture positions the lead and sets the previous tick.
  mobile.evaluate('game.tick=3593;game.player=point(19,6);game.enemies=[];game.warnings=[];game.waveIndex=game.waves.length;void 0')
  mobile.wait_for_selector('[data-pick]')
  def inside(page,selector):
   return page.locator(selector).evaluate_all('(nodes)=>nodes.length>0&&nodes.every(n=>{const r=n.getBoundingClientRect();return r.width>0&&r.left>=0&&r.top>=0&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1;})')
  assert inside(mobile,'.recruit .card') and inside(mobile,'#door')
  assert mobile.locator('.turnline').inner_text()=='Your Move, My Lord.'
  if os.environ.get('BLACK_MOVE_SCREENS'):mobile.screenshot(path=str(ROOT/'mobile-choice.png'))
  mobile.set_viewport_size({'width':320,'height':568});assert inside(mobile,'.recruit .card')
  mobile.locator('[data-pick=meyrin]').tap();assert mobile.evaluate("game.room===1&&game.units[0].key==='meyrin'&&game.deck.length===5")
  rows.extend(['일시정지 복귀 시 같은 대사 노드 유지','세로 390×844·320×568 후보 3장 표시 및 터치 영입'])
  # A separate max-tier fixture checks touch responsiveness while the real renderer is drawing the barrage.
  mobile.evaluate('game.silver.tier=6;game.silver.count=SILVER_TIERS[6].need;void 0')
  mobile.wait_for_function('game.shots.length>=130')
  x0=mobile.evaluate('game.player.x')
  touch('touchStart',100,255);touch('touchMove',146,255)
  mobile.wait_for_function('x=>game.player.x>x+0.8',arg=x0);touch('touchEnd')
  assert mobile.evaluate('game.shots.length>=100 && game.silver.tier===6')
  rows.append('320×568 최고 단계 고정 배치에서 탄막 진행 중 터치 이동')
  mobile.close()
  pc=b.new_page(viewport={'width':1366,'height':768});pc.on('pageerror',lambda e:errors.append(str(e)))
  pc.goto(HTML.as_uri());pc.locator('#config').click();pc.locator('#projection').select_option('iso');pc.locator('#seed').fill('116')
  pc.get_by_role('button',name='규칙 테스트 실행').click();pc.wait_for_selector('.testlog')
  result=pc.locator('.testlog').inner_text().splitlines()
  assert all(x.startswith('✓') for x in result),result
  pc.get_by_role('button',name='닫기').click();pc.get_by_role('button',name='설정 적용').click();pc.locator('#start').click()
  pc.wait_for_function('game.tick>=3 && Number.isFinite(project(game.player).x)')
  px=pc.evaluate('project(game.player)');start_tick=pc.evaluate('game.tick');pc.keyboard.down('ArrowRight');pc.wait_for_function('t=>game.tick>=t+28',arg=start_tick);pc.keyboard.up('ArrowRight');py=pc.evaluate('project(game.player)')
  assert py['x']>px['x']+8 and abs(py['y']-px['y'])<1.5
  pc.locator('#config').click();pc.locator('#projection').select_option('top');pc.get_by_role('button',name='설정 적용').click()
  old_y=pc.evaluate('game.player.y');start_tick=pc.evaluate('game.tick');pc.keyboard.down('ArrowDown');pc.wait_for_function('t=>game.tick>=t+22',arg=start_tick);pc.keyboard.up('ArrowDown');assert pc.evaluate('game.player.y')>old_y+.9
  rows.append('1366×768 탑뷰·등각 전환 및 실제 방향키가 화면 방향으로 이동')
  pc.evaluate('game.tick=3599;game.player=point(19,6);game.waveIndex=game.waves.length;void 0');pc.wait_for_selector('[data-pick]')
  assert inside(pc,'.recruit .card')
  if os.environ.get('BLACK_MOVE_SCREENS'):pc.screenshot(path=str(ROOT/'pc-choice.png'))
  pc.locator('[data-pick=meyrin]').dblclick();assert pc.evaluate('game.room===1&&game.deck.length===5')
  rows.append('데스크톱 후보 동시 표시 · 더블클릭 방 전환 1회')
  pc.evaluate("game.facing=point(1,0);game.player=point(12,6);game.trail=[point(9,6),point(12,6)];Object.assign(game.units[0],point(10.6,6));game.enemies=[];game.warnings=[];game.enemy('chaser',9.6,6);game.enemy('chaser',8,6);game.enemy('chaser',8.8,6.6);game.cool=Infinity;game.units[0].ready=0;game.step();void 0")
  assert pc.evaluate('game.enemies[0].hp===4&&game.enemies[1].hp===4&&game.enemies[2].hp===18')
  rows.append('브라우저 고정 배치 사선 피해 14·14·0')
  assert not errors,errors
  print(json.dumps({'browser':b.version,'real_and_layout':rows,'rules':result},ensure_ascii=False,indent=2))
  (ROOT/'controls_result.json').write_text(json.dumps({'browser':b.version,'real_and_layout':rows,'rules':result},ensure_ascii=False,indent=2),encoding='utf-8')
  b.close()
if __name__=='__main__':run()
