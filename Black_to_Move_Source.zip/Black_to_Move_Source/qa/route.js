function routeDriver() {
  const courses = [[[2, 2.2], [17.7, 2.2], [17.7, 9.8], [2, 9.8]], [[2, 2.05], [18, 2.05], [18, 6.25], [2, 6.25]], [[9.9, 3.6], [16, 3.6], [16, 8.4], [9.9, 8.4]]];
  let index = 0, lastRoom = -1, lastAdvance = 0;
  return function route(g) {
    if (g.room !== lastRoom) {
      index = 0;
      lastAdvance = 0;
      lastRoom = g.room;
    }
    let p = g.player, course = courses[g.room], target = point(...course[index % course.length]);
    if (distance(p, target) < 1.3 || g.tick - lastAdvance > 430) {
      index++;
      lastAdvance = g.tick;
      target = point(...course[index % course.length]);
    }
    if (g.door) {
      target = navigate(g.room, p, point(19, 6), .22);
    }
    const dx = target.x - p.x, dy = target.y - p.y;
    if (Math.hypot(dx, dy) < .05)return [];
    const keys = [];
    if (Math.abs(dx) > .13 && Math.abs(dx) > .35 * Math.abs(dy))keys.push(dx > 0?'d':'a');
    if (Math.abs(dy) > .13 && Math.abs(dy) > .35 * Math.abs(dx))keys.push(dy > 0?'s':'w');
    const dirs = [['d'], ['s'], ['a'], ['w'], ['d', 's'], ['a', 's'], ['a', 'w'], ['d', 'w']];
    const goal = to(p, target);
    let best = keys, bestScore = -Infinity;
    for (const keys of dirs) {
      const v = unit(+keys.includes('d') - keys.includes('a'), +keys.includes('s') - keys.includes('w'));
      let score = dot(v, goal) * 5;
      for (const horizon of [.25, .55, .85, 1.2]) {
        const sec=g.door?Math.min(horizon,distance(p,target)/3.2):horizon;
        const pos = point(p.x + v.x * 3.2 * sec, p.y + v.y * 3.2 * sec);
        if (!free(g.room, pos, .22)) {
          const here = copyPoint(p);
          travel(g.room, here, v.x * 3.2 * sec, v.y * 3.2 * sec, .22);
          score -= distance(pos, here) * 1.8;
          pos.x = here.x;
          pos.y = here.y;
        }
        let safe = 4;
        for (const e of g.enemies) {
          const edir = to(e, p);
          if (e.mode === 'warn' || e.mode === 'dash') {
            for (const t of [0, .3, .6])safe = Math.min(safe, distance(pos, point(e.x + e.dx * 5 * t, e.y + e.dy * 5 * t)) - .25);
          }else{
            const vel = e.mode === 'rest'?0:e.speed;
            safe = Math.min(safe, distance(pos, point(e.x + edir.x * vel * sec * .85, e.y + edir.y * vel * sec * .85)));
          }
        }
        score -= Math.max(0, 2.05 - safe) * (1.6 - sec) * 3;
      }
      if (score > bestScore) {
        bestScore = score;
        best = keys;
      }
    }
    return best;
  };
}
