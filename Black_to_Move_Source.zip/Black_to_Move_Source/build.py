"""Assemble the self-contained game. Python 3.9+ standard library, no package installation."""
from base64 import b64encode
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "src"
OUTPUT = ROOT / "Black_to_Move.html"
PARTS = {
    "STYLE": "style.css",
    "ASSETS": "assets.js",
    "SILVER": "silver.js",
    "SILVER_ART": "silver-art.js",
    "ENGINE": "engine.js",
    "PRIMITIVES": "primitives.js",
    "RENDER": "render.js",
    "TESTS": "tests.js",
    "UI": "ui.js",
}

ART = SOURCE / "art"
CSS_IMAGES = {"cover": "nocturne.webp"}

def data_url(path):
    mime = {".webp": "image/webp", ".svg": "image/svg+xml", ".woff": "font/woff"}[path.suffix]
    return f"data:{mime};base64," + b64encode(path.read_bytes()).decode("ascii")

def build():
    page = (SOURCE / "page.html").read_text(encoding="utf-8")
    for slot, filename in PARTS.items():
        content = (SOURCE / filename).read_text(encoding="utf-8")
        if slot == "STYLE":
            variables = [f'--{name}:url("{data_url(ART / file)}")' for name, file in CSS_IMAGES.items()]
            content = ":root{" + ";".join(variables) + "}\n" + content
        if slot == "ASSETS":
            images = {group: {p.stem: data_url(p) for p in sorted((ART / group).glob("*.webp"))}
                      for group in ("figures", "rooms", "props", "portraits")}
            content += "const MANOR = " + json.dumps(images, separators=(",", ":")) + ";\n"
        marker = "/*" + slot + "*/"
        if page.count(marker) != 1:
            raise ValueError(f"Expected one template marker for {slot}")
        page = page.replace(marker, content)
    OUTPUT.write_bytes(page.encode("utf-8"))
    print(f"Built {OUTPUT}")

if __name__ == "__main__":
    build()
